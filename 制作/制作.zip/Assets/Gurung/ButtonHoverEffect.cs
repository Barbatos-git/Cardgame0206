using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class ButtonHoverEffect : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("Scale Settings")]
    [SerializeField] private float hoverScale = 1.2f; // How much bigger on hover
    [SerializeField] private float animationSpeed = 5f; // Speed of the animation

    [Header("Animation Curve")]
    [SerializeField] private AnimationCurve easeCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);

    private TextMeshProUGUI buttonText;
    private Text legacyText;
    private Vector3 originalScale;
    private Vector3 targetScale;
    private bool isHovering = false;
    private float currentProgress = 0f;

    void Start()
    {
        // Try to get TextMeshPro text first
        buttonText = GetComponentInChildren<TextMeshProUGUI>();

        // If not found, try legacy Text component
        if (buttonText == null)
        {
            legacyText = GetComponentInChildren<Text>();
        }

        // Store original scale
        if (buttonText != null)
        {
            originalScale = buttonText.transform.localScale;
        }
        else if (legacyText != null)
        {
            originalScale = legacyText.transform.localScale;
        }
        else
        {
            Debug.LogWarning("No Text component found on button!");
            originalScale = Vector3.one;
        }

        targetScale = originalScale;
    }

    void Update()
    {
        // Smoothly animate to target scale
        if (isHovering)
        {
            currentProgress = Mathf.Min(currentProgress + Time.deltaTime * animationSpeed, 1f);
        }
        else
        {
            currentProgress = Mathf.Max(currentProgress - Time.deltaTime * animationSpeed, 0f);
        }

        // Apply easing curve
        float easedProgress = easeCurve.Evaluate(currentProgress);
        Vector3 newScale = Vector3.Lerp(originalScale, originalScale * hoverScale, easedProgress);

        // Apply scale to the text
        if (buttonText != null)
        {
            buttonText.transform.localScale = newScale;
        }
        else if (legacyText != null)
        {
            legacyText.transform.localScale = newScale;
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovering = true;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovering = false;
    }
}