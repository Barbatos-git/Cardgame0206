using UnityEngine;
using UnityEngine.SceneManagement;

public class BGMManager : MonoBehaviour
{
    [Header("BGM Settings")]
    [SerializeField] private AudioClip backgroundMusic;
    [SerializeField] private float volume = 0.5f;
    [SerializeField] private bool playOnAwake = true;
    [SerializeField] private bool loop = true;

    [Header("Fade Settings")]
    [SerializeField] private bool useFade = false;
    [SerializeField] private float fadeInDuration = 2f;
    [SerializeField] private float fadeOutDuration = 1f;

    private AudioSource audioSource;
    private static BGMManager instance;
    private float targetVolume;
    private bool isFading = false;

    void Awake()
    {
        // Singleton pattern - only one BGM Manager exists
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // Persist across scenes
            SetupAudioSource();
        }
        else
        {
            Destroy(gameObject); // Destroy duplicate
            return;
        }
    }

    void Start()
    {
        if (playOnAwake && backgroundMusic != null)
        {
            PlayBGM();
        }
    }

    void Update()
    {
        // Handle volume fading
        if (isFading && audioSource != null)
        {
            audioSource.volume = Mathf.MoveTowards(audioSource.volume, targetVolume, Time.deltaTime / fadeInDuration);

            if (Mathf.Approximately(audioSource.volume, targetVolume))
            {
                isFading = false;
            }
        }
    }

    void SetupAudioSource()
    {
        audioSource = gameObject.GetComponent<AudioSource>();

        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }

        audioSource.clip = backgroundMusic;
        audioSource.loop = loop;
        audioSource.playOnAwake = false;
        audioSource.volume = useFade ? 0f : volume;
        targetVolume = volume;
    }

    public void PlayBGM()
    {
        if (audioSource != null && backgroundMusic != null)
        {
            if (!audioSource.isPlaying)
            {
                audioSource.Play();

                if (useFade)
                {
                    audioSource.volume = 0f;
                    FadeIn();
                }
            }
        }
    }

    public void StopBGM()
    {
        if (audioSource != null && audioSource.isPlaying)
        {
            if (useFade)
            {
                FadeOut();
            }
            else
            {
                audioSource.Stop();
            }
        }
    }

    public void PauseBGM()
    {
        if (audioSource != null && audioSource.isPlaying)
        {
            audioSource.Pause();
        }
    }

    public void ResumeBGM()
    {
        if (audioSource != null && !audioSource.isPlaying)
        {
            audioSource.UnPause();
        }
    }

    public void ChangeBGM(AudioClip newClip, bool fadeTransition = true)
    {
        if (newClip == null) return;

        if (fadeTransition && useFade)
        {
            StartCoroutine(ChangeBGMWithFade(newClip));
        }
        else
        {
            audioSource.clip = newClip;
            backgroundMusic = newClip;
            audioSource.Play();
        }
    }

    public void SetVolume(float newVolume)
    {
        volume = Mathf.Clamp01(newVolume);
        targetVolume = volume;

        if (audioSource != null && !isFading)
        {
            audioSource.volume = volume;
        }
    }

    private void FadeIn()
    {
        targetVolume = volume;
        isFading = true;
    }

    private void FadeOut()
    {
        targetVolume = 0f;
        isFading = true;
        Invoke(nameof(StopAfterFade), fadeOutDuration);
    }

    private void StopAfterFade()
    {
        if (audioSource != null)
        {
            audioSource.Stop();
        }
    }

    private System.Collections.IEnumerator ChangeBGMWithFade(AudioClip newClip)
    {
        // Fade out current music
        float startVolume = audioSource.volume;
        float elapsed = 0f;

        while (elapsed < fadeOutDuration)
        {
            elapsed += Time.deltaTime;
            audioSource.volume = Mathf.Lerp(startVolume, 0f, elapsed / fadeOutDuration);
            yield return null;
        }

        // Change clip
        audioSource.clip = newClip;
        backgroundMusic = newClip;
        audioSource.Play();

        // Fade in new music
        elapsed = 0f;
        while (elapsed < fadeInDuration)
        {
            elapsed += Time.deltaTime;
            audioSource.volume = Mathf.Lerp(0f, volume, elapsed / fadeInDuration);
            yield return null;
        }

        audioSource.volume = volume;
    }

    // Public getter for instance
    public static BGMManager Instance
    {
        get { return instance; }
    }
}