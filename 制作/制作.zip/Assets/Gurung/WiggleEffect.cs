using UnityEngine;

public class WiggleEffect : MonoBehaviour
{
    [Header("Wiggle Settings")]
    [SerializeField] private float wiggleSpeed = 0.5f;
    [SerializeField] private float wiggleAmountX = 0.2f;
    [SerializeField] private float wiggleAmountY = 0.1f;

    [Header("Depth/Parallax")]
    [SerializeField] private float depthLayer = 1f;

    [Header("Rotation Wiggle (Optional)")]
    [SerializeField] private bool enableRotation = false;
    [SerializeField] private float rotationAmount = 2f;

    private Vector3 startPosition;
    private Quaternion startRotation;
    private float randomOffset;

    void Start()
    {
        startPosition = transform.position;
        startRotation = transform.rotation;
        randomOffset = Random.Range(0f, 100f);
    }

    void Update()
    {
        float time = Time.time * wiggleSpeed + randomOffset;

        float offsetX = Mathf.Sin(time) * wiggleAmountX * depthLayer;
        float offsetY = Mathf.Cos(time * 0.8f) * wiggleAmountY * depthLayer;

        transform.position = startPosition + new Vector3(offsetX, offsetY, 0f);

        if (enableRotation)
        {
            float rotZ = Mathf.Sin(time * 0.5f) * rotationAmount * depthLayer;
            transform.rotation = startRotation * Quaternion.Euler(0f, 0f, rotZ);
        }
    }
}