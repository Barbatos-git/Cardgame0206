using UnityEngine;
using System.Collections;

public class CardRainEffect : MonoBehaviour
{
    [Header("Card Settings")]
    [SerializeField] private GameObject cardPrefab; // Your card prefab
    [SerializeField] private Sprite[] cardSprites; // Different card designs (optional)
    [SerializeField] private Sprite backSprite; // The back face sprite (same for all cards)

    [Header("Spawn Settings")]
    [SerializeField] private float spawnRate = 0.3f; // Time between card spawns
    [SerializeField] private int maxCards = 50; // Maximum cards on screen
    [SerializeField] private float spawnWidth = 10f; // Horizontal spawn area width
    [SerializeField] private float spawnHeight = 2f; // Height above screen to spawn

    [Header("Fall Settings")]
    [SerializeField] private float fallSpeedMin = 2f;
    [SerializeField] private float fallSpeedMax = 5f;
    [SerializeField] private float rotationSpeedMin = 50f;
    [SerializeField] private float rotationSpeedMax = 150f;
    [SerializeField] private float swayAmount = 1f; // Horizontal sway while falling
    [SerializeField] private float swaySpeed = 2f;

    [Header("Card Size")]
    [SerializeField] private float cardScaleMin = 0.5f;
    [SerializeField] private float cardScaleMax = 1f;

    [Header("Destruction")]
    [SerializeField] private float destroyBelowY = -10f; // Destroy cards below this Y position

    private int currentCardCount = 0;
    private bool isRaining = true;

    void Start()
    {
        StartCoroutine(SpawnCards());
    }

    IEnumerator SpawnCards()
    {
        while (isRaining)
        {
            if (currentCardCount < maxCards && cardPrefab != null)
            {
                SpawnCard();
            }

            yield return new WaitForSeconds(spawnRate);
        }
    }

    void SpawnCard()
    {
        // Random spawn position at top of screen
        Vector3 spawnPos = new Vector3(
            Random.Range(-spawnWidth / 2f, spawnWidth / 2f),
            Camera.main.transform.position.y + spawnHeight,
            0f
        );

        // Instantiate card
        GameObject card = Instantiate(cardPrefab, spawnPos, Quaternion.Euler(0, 0, Random.Range(0f, 360f)));

        // Random scale
        float scale = Random.Range(cardScaleMin, cardScaleMax);
        card.transform.localScale = Vector3.one * scale;

        // Select a random front sprite
        Sprite frontSprite = null;
        if (cardSprites != null && cardSprites.Length > 0)
        {
            frontSprite = cardSprites[Random.Range(0, cardSprites.Length)];
        }

        SpriteRenderer spriteRenderer = card.GetComponent<SpriteRenderer>();
        if (spriteRenderer != null && frontSprite != null)
        {
            spriteRenderer.sprite = frontSprite;
        }

        // Add falling behavior with flip
        FallingCard fallingCard = card.AddComponent<FallingCard>();
        fallingCard.Initialize(
            Random.Range(fallSpeedMin, fallSpeedMax),
            Random.Range(rotationSpeedMin, rotationSpeedMax),
            swayAmount,
            swaySpeed,
            destroyBelowY,
            this,
            frontSprite,
            backSprite
        );

        currentCardCount++;
    }

    public void CardDestroyed()
    {
        currentCardCount--;
    }

    public void StartRain()
    {
        if (!isRaining)
        {
            isRaining = true;
            StartCoroutine(SpawnCards());
        }
    }

    public void StopRain()
    {
        isRaining = false;
    }
}

// Separate component for individual card behavior
public class FallingCard : MonoBehaviour
{
    private float fallSpeed;
    private float rotationSpeed;
    private float swayAmount;
    private float swaySpeed;
    private float destroyY;
    private CardRainEffect manager;
    private float startX;
    private float timeOffset;

    // Flip variables
    private SpriteRenderer spriteRenderer;
    private Sprite frontSprite;
    private Sprite backSprite;
    private float currentYRotation = 0f;
    private bool showingFront = true;

    public void Initialize(float fall, float rotation, float sway, float swaySpd, float destroyY, CardRainEffect mgr, Sprite front, Sprite back)
    {
        fallSpeed = fall;
        rotationSpeed = rotation * (Random.value > 0.5f ? 1f : -1f); // Random rotation direction
        swayAmount = sway;
        swaySpeed = swaySpd;
        this.destroyY = destroyY;
        manager = mgr;
        startX = transform.position.x;
        timeOffset = Random.Range(0f, 100f);

        // Flip setup
        spriteRenderer = GetComponent<SpriteRenderer>();
        frontSprite = front;
        backSprite = back;

        // Start with random Y rotation
        currentYRotation = Random.Range(0f, 360f);
    }

    void Update()
    {
        // Fall down
        transform.position += Vector3.down * fallSpeed * Time.deltaTime;

        // Sway left and right
        float sway = Mathf.Sin((Time.time + timeOffset) * swaySpeed) * swayAmount;
        transform.position = new Vector3(startX + sway, transform.position.y, transform.position.z);

        // Rotate on Z axis (spinning)
        transform.Rotate(0, 0, rotationSpeed * Time.deltaTime);

        // Rotate on Y axis (flipping front/back)
        currentYRotation += rotationSpeed * 0.5f * Time.deltaTime; // Flip at half the spin speed
        if (currentYRotation >= 360f) currentYRotation -= 360f;

        transform.rotation = Quaternion.Euler(0, currentYRotation, transform.rotation.eulerAngles.z);

        // Switch sprite based on Y rotation (show back when card is facing away)
        if (spriteRenderer != null && backSprite != null && frontSprite != null)
        {
            // When Y rotation is between 90-270 degrees, show back
            if (currentYRotation > 90f && currentYRotation < 270f)
            {
                if (showingFront)
                {
                    spriteRenderer.sprite = backSprite;
                    showingFront = false;
                }
            }
            else
            {
                if (!showingFront)
                {
                    spriteRenderer.sprite = frontSprite;
                    showingFront = true;
                }
            }
        }

        // Destroy if below screen
        if (transform.position.y < destroyY)
        {
            manager.CardDestroyed();
            Destroy(gameObject);
        }
    }
}