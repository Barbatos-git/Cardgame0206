using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class UICardFlip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("Card Sprites")]
    [SerializeField] private Sprite frontSprite;
    [SerializeField] private Sprite backSprite;

    [Header("Flip Animation")]
    [SerializeField] private float flipDuration = 0.3f;
    [SerializeField] private AnimationCurve flipCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);

    private Image cardImage;
    private RectTransform rectTransform;
    private bool isFlipping = false;
    private bool showingBack = false;
    private float flipProgress = 0f;
    private bool shouldFlipToBack = false;

    void Start()
    {
        cardImage = GetComponent<Image>();
        rectTransform = GetComponent<RectTransform>();

        if (cardImage == null)
        {
            Debug.LogError("No Image component found! This script needs to be on a UI Image.");
            return;
        }

        // Set initial sprite to front
        if (frontSprite != null)
        {
            cardImage.sprite = frontSprite;
        }
    }

    void Update()
    {
        if (isFlipping)
        {
            flipProgress += Time.deltaTime / flipDuration;

            if (flipProgress >= 1f)
            {
                flipProgress = 1f;
                isFlipping = false;
            }

            // Apply flip animation
            float curvedProgress = flipCurve.Evaluate(flipProgress);
            float scaleX = Mathf.Cos(curvedProgress * Mathf.PI);
            rectTransform.localScale = new Vector3(Mathf.Abs(scaleX), 1f, 1f);

            // Switch sprite at halfway point (when card is edge-on)
            if (flipProgress >= 0.5f && cardImage != null)
            {
                if (shouldFlipToBack && !showingBack)
                {
                    cardImage.sprite = backSprite;
                    showingBack = true;
                }
                else if (!shouldFlipToBack && showingBack)
                {
                    cardImage.sprite = frontSprite;
                    showingBack = false;
                }
            }
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        FlipToBack();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        FlipToFront();
    }

    public void FlipToBack()
    {
        if (!showingBack && !isFlipping)
        {
            shouldFlipToBack = true;
            StartFlip();
        }
    }

    public void FlipToFront()
    {
        if (showingBack && !isFlipping)
        {
            shouldFlipToBack = false;
            StartFlip();
        }
    }

    private void StartFlip()
    {
        isFlipping = true;
        flipProgress = 0f;
    }
}