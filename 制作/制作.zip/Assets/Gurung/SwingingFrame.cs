using UnityEngine;

public class SwingingFrame : MonoBehaviour
{
    [Header("Swing Settings")]
    [SerializeField] private float swingSpeed = 1f;
    [SerializeField] private float swingAngle = 5f; // Maximum rotation angle in degrees

    [Header("Swing Behavior")]
    [SerializeField] private bool randomSwing = false; // Random swing or constant
    [SerializeField] private float dampingEffect = 0.98f; // Makes swing gradually slow down (only if random)

    [Header("Pivot Point")]
    [SerializeField] private Vector3 pivotOffset = new Vector3(0f, 0.5f, 0f); // Where the rope attaches (top of frame)

    private Quaternion startRotation;
    private float currentAngle;
    private float swingVelocity;
    private float randomTime;

    void Start()
    {
        startRotation = transform.rotation;

        if (randomSwing)
        {
            // Start with a random push
            swingVelocity = Random.Range(-swingAngle * 0.5f, swingAngle * 0.5f);
            randomTime = Random.Range(0f, 100f);
        }
    }

    void Update()
    {
        if (randomSwing)
        {
            // Pendulum physics simulation
            float gravity = -Mathf.Sin(currentAngle * Mathf.Deg2Rad) * swingSpeed * 10f;
            swingVelocity += gravity * Time.deltaTime;
            swingVelocity *= dampingEffect; // Damping
            currentAngle += swingVelocity * Time.deltaTime;

            // Clamp to max angle
            currentAngle = Mathf.Clamp(currentAngle, -swingAngle, swingAngle);
        }
        else
        {
            // Smooth sine wave swing
            currentAngle = Mathf.Sin(Time.time * swingSpeed) * swingAngle;
        }

        // Apply rotation around the pivot point (rope attachment)
        transform.rotation = startRotation * Quaternion.Euler(0f, 0f, currentAngle);
    }

    // Optional: Visualize the pivot point in editor
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position + transform.TransformDirection(pivotOffset), 0.05f);
    }
}