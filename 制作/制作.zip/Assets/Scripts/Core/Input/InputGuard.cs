﻿/// <summary>
/// Core 层输入守卫：通过接口注入检测“鼠标是否在 UI 上”
/// Core 不依赖 EventSystem
/// </summary>
public static class InputGuard
{
    // 注入点（由 UI 层实现并注册）
    public static IPointerOnUIDetector Detector { get; set; }

    public static bool PointerOnUI()
    {
        return Detector != null && Detector.IsPointerOnUI();
    }
}
