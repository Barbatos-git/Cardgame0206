﻿namespace CardGame.Core.Pause
{
    public interface IPauseService
    {
        bool IsPaused { get; }
        void SetPaused(bool paused);
        void Toggle();
    }
}
