﻿using System;

namespace CardGame.Core.Pause
{
    public static class PauseEvents
    {
        public static event Action<bool> OnPauseChanged;

        public static void RaisePauseChanged(bool isPaused)
            => OnPauseChanged?.Invoke(isPaused);
    }
}
