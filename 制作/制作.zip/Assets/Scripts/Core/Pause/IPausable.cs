﻿namespace CardGame.Core.Pause
{
    public interface IPausable
    {
        void Pause();
        void Resume();
    }
}
