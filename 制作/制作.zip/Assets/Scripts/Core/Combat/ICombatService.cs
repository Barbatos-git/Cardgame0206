using System;
using CardGame.Core.Combat;

namespace CardGame.Core.Combat
{
    /// <summary>
    /// 戦闘を要求するための窓口
    /// </summary>
    public interface ICombatService
    {
        event Action<AttackResult> OnAttackResolved;

        /// <summary>
        /// 「攻撃したい」を送る
        /// </summary>
        void RequestAttack(ICombatant attacker, ICombatant defender);
    }
}
