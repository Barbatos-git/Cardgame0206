using System;

namespace CardGame.Core.Combat
{
    /// <summary>
    /// 戦闘可能なカード（味方/敵 共通）
    /// </summary>
    public interface ICombatant
    {
        string DebugName { get; }

        int Attack { get; }
        int MaxHP { get; }
        int HP { get; }
        bool IsDead { get; }

        /// <summary> 1ターン1回などの制約用（後でターン制にするならここを拡張）</summary>
        bool CanAttack { get; }

        event Action<int> OnHPChanged;
        event Action OnDied;

        void TakeDamage(int amount, DamageType type = DamageType.Normal);
        void Heal(int amount);
    }
}
