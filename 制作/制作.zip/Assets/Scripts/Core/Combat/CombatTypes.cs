namespace CardGame.Core.Combat
{
    /// <summary>
    /// ダメージ種別（拡張用）
    /// </summary>
    public enum DamageType
    {
        Normal,
        True,
    }

    /// <summary>
    /// 攻撃解決時に必要な最小情報
    /// </summary>
    public readonly struct AttackCommand
    {
        public readonly ICombatant Attacker;
        public readonly ICombatant Defender;

        public AttackCommand(ICombatant attacker, ICombatant defender)
        {
            Attacker = attacker;
            Defender = defender;
        }
    }

    /// <summary>
    /// 攻撃結果（ログ/演出/リプレイ用に拡張しやすい）
    /// </summary>
    public readonly struct AttackResult
    {
        public readonly int DamageToDefender;
        public readonly int DamageToAttacker;
        public readonly bool DefenderDied;
        public readonly bool AttackerDied;

        public AttackResult(int dmgDef, int dmgAtk, bool defDied, bool atkDied)
        {
            DamageToDefender = dmgDef;
            DamageToAttacker = dmgAtk;
            DefenderDied = defDied;
            AttackerDied = atkDied;
        }
    }
}
