using System;
using CardGame.Core.Cards;

namespace CardGame.Core.Zones
{
    /// <summary>
    /// 人物カードを受け入れる「機能区」インターフェース
    /// 探索区/伐採場/採石場/戦闘区など全部これで統一
    /// </summary>
    public interface IZone
    {
        string ZoneId { get; }
        string DebugName { get; }

        bool CanEnter(ICardEntity card);
        void Enter(ICardEntity card);
        void Exit(ICardEntity card);

        event Action<ICardEntity> OnEntered;
        event Action<ICardEntity> OnExited;
    }
}
