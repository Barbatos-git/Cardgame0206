using UnityEngine;

public interface IFusionZoneHost
{
    /// <summary>
    /// 生成并注册一个合成区（位置/布局由 UI 内部决定）
    /// </summary>
    GameObject SpawnFusionZone(GameObject fusionZonePrefab, GameObject ownerCard);

    /// <summary>
    /// 注销并销毁合成区
    /// </summary>
    void DespawnFusionZone(GameObject spawnedZone);
}
