﻿public interface IFusionButtonStateSink
{
    // Toggle(+/×) 控制：展开可见性
    void SetExpandedVisible(bool expandedVisible);

    // FusionZone 控制：是否允许合成
    void SetCanFuse(bool canFuse);
}
