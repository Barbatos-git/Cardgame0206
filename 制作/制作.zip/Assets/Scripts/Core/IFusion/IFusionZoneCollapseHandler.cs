public interface IFusionZoneCollapseHandler
{
    /// <summary>
    /// UI 收起合成区前调用：
    /// - 返回 true：允许继续收起（内部可做“驱逐卡牌”等收尾）
    /// - 返回 false：不允许收起（比如想做“有卡就禁止收起”）
    /// </summary>
    bool OnBeforeCollapse();
}
