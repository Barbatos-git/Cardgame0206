using UnityEngine;

public static class FusionZoneHostLocator
{
    private static IFusionZoneHost _cached;

    public static IFusionZoneHost Get()
    {
        if (_cached != null) return _cached;

        // 不引用 UI 类型，只扫描场景里的 MonoBehaviour 找接口
#if UNITY_2023_1_OR_NEWER
        var behaviours = Object.FindObjectsByType<MonoBehaviour>(FindObjectsSortMode.None);
#else
        var behaviours = Object.FindObjectsOfType<MonoBehaviour>();
#endif
        foreach (var b in behaviours)
        {
            if (b is IFusionZoneHost host)
            {
                _cached = host;
                return _cached;
            }
        }

        return null;
    }

    public static void ClearCache() => _cached = null;
}
