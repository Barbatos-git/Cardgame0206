﻿/// <summary>
/// UI 侧发起“合成请求”的统一入口（UI 不依赖 Gameplay 类型）
/// </summary>
public interface IFusionActionSource
{
    void RequestFuse();
}
