﻿using System;
using UnityEngine;

/// <summary>
/// Core 层世界事件（不依赖 Gameplay 类型）
/// </summary>
public static class WorldEvents
{
    /// <summary>
    /// 某个“世界对象(堆根)”的位置发生变化
    /// rootId：GameObject.GetInstanceID()
    /// pos：变化后的世界位置
    /// </summary>
    public static event Action<int, Vector3> StackRootWorldPositionChanged;

    public static void RaiseStackRootWorldPositionChanged(int rootId, Vector3 pos)
    {
        StackRootWorldPositionChanged?.Invoke(rootId, pos);
    }
}
