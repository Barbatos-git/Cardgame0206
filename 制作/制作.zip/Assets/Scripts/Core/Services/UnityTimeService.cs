using UnityEngine;

namespace CardGame.Core.Services
{
    public sealed class UnityTimeService : IFrameTime
    {
        public float DeltaTime => UnityEngine.Time.deltaTime;
        public float Time => UnityEngine.Time.time;
    }
}