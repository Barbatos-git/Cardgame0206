﻿using System;

namespace CardGame.Core.Time
{
    /// <summary>
    /// 时间事件总线（纯 C#，不依赖 Unity）
    /// </summary>
    public static class TimeEvents
    {
        /// <summary>天数变化（day 已经 +1 后触发）</summary>
        public static event Action<int> OnDayChanged;

        /// <summary>一天结束结算点（在 day++ 前/后都行，这里约定：先 DayEnd 再 DayChanged）</summary>
        public static event Action<int> OnDayEnded;

        public static void RaiseDayEnded(int currentDay) => OnDayEnded?.Invoke(currentDay);
        public static void RaiseDayChanged(int newDay) => OnDayChanged?.Invoke(newDay);
    }
}
