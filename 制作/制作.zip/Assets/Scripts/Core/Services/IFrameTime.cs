namespace CardGame.Core.Services
{
    /// <summary>
    /// テスト容易性のための時間サービス
    /// </summary>
    public interface IFrameTime
    {
        float DeltaTime { get; }
        float Time { get; }
    }
}
