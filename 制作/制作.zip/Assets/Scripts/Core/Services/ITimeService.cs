﻿namespace CardGame.Core.Time
{
    public interface ITimeService
    {
        int CurrentDay { get; }
        int CurrentTick { get; }
        int TicksPerDay { get; }

        /// <summary>推进时间（行为驱动 or 自动驱动都可以调用）</summary>
        void AddTick(int amount = 1);

        /// <summary>直接结束当天（调试用）</summary>
        void ForceEndDay();
    }
}
