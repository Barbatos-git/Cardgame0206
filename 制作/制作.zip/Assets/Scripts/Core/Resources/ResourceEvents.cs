﻿using System;

namespace CardGame.Core.Resources
{
    public static class ResourceEvents
    {
        /// <summary>资源变化事件（变化后触发）</summary>
        public static event Action<ResourceType, int> OnResourceChanged;

        public static void RaiseChanged(ResourceType type, int newValue)
            => OnResourceChanged?.Invoke(type, newValue);
    }
}
