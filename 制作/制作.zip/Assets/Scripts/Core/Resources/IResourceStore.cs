﻿namespace CardGame.Core.Resources
{
    /// <summary>
    /// 资源仓库接口：Gameplay 用卡牌堆/背包实现它；UI 只读它（通过引用或事件）。
    /// </summary>
    public interface IResourceStore
    {
        int Get(ResourceType type);

        /// <summary>尝试消耗，成功返回 true</summary>
        bool TryConsume(ResourceType type, int amount);

        /// <summary>增加资源</summary>
        void Add(ResourceType type, int amount);
    }
}
