﻿namespace CardGame.Core.Resources
{
    public enum ResourceType
    {
        Food = 0,
        // Wood, Stone, Gold... 以后扩展
    }

    public readonly struct ResourceDelta
    {
        public readonly ResourceType Type;
        public readonly int Amount; // + 增加，- 消耗

        public ResourceDelta(ResourceType type, int amount)
        {
            Type = type;
            Amount = amount;
        }
    }
}
