using UnityEngine;

namespace CardGame.Core.Cards
{
    /// <summary>
    /// カードとしての最小共通インターフェース（見た目/UI/入力は別層）
    /// </summary>
    public interface ICardEntity
    {
        int InstanceId { get; }
        string DebugName { get; }

        Transform Transform { get; }

        /// <summary>
        /// カードが破棄される（死亡/消滅など）
        /// </summary>
        void Despawn();
    }
}
