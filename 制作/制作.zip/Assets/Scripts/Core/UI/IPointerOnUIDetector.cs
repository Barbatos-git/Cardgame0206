public interface IPointerOnUIDetector
{
    bool IsPointerOnUI();
}
