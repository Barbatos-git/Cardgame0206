﻿#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using System.IO;

public static class CardGameAsmdefSetup
{
    private const string RootPath = "Assets/Scripts";

    [MenuItem("Tools/Card Game/生成基础 asmdef 结构")]
    public static void CreateAsmdefs()
    {
        // 确保根目录存在
        EnsureFolder(RootPath);

        CreateAsmdefWithFolder("Core", "CardGame.Core");
        CreateAsmdefWithFolder("Data", "CardGame.Data");
        CreateAsmdefWithFolder("Gameplay", "CardGame.Gameplay");
        CreateAsmdefWithFolder("UI", "CardGame.UI");
        CreateAsmdefWithFolder("Editor", "CardGame.Editor");

        AssetDatabase.Refresh();
        Debug.Log("CardGame asmdef 结构创建完毕，请到各 asmdef 里手动设置依赖关系。");
    }

    private static void CreateAsmdefWithFolder(string subFolder, string asmdefName)
    {
        string folderPath = $"{RootPath}/{subFolder}";
        EnsureFolder(folderPath);

        string asmdefPath = $"{folderPath}/{asmdefName}.asmdef";
        if (File.Exists(asmdefPath))
        {
            Debug.LogWarning($"已存在 asmdef: {asmdefPath}");
            return;
        }

        string json = GetAsmdefJson(asmdefName);
        File.WriteAllText(asmdefPath, json);
        Debug.Log($"创建 asmdef: {asmdefPath}");
    }

    private static void EnsureFolder(string path)
    {
        if (!AssetDatabase.IsValidFolder(path))
        {
            string parent = Path.GetDirectoryName(path).Replace("\\", "/");
            string folderName = Path.GetFileName(path);
            AssetDatabase.CreateFolder(parent, folderName);
        }
    }

    /// <summary>
    /// 最基础的 asmdef json，先不设 references，之后在 Inspector 设置即可
    /// </summary>
    private static string GetAsmdefJson(string name)
    {
        return
$@"{{
    ""name"": ""{name}"",
    ""references"": [],
    ""includePlatforms"": [],
    ""excludePlatforms"": [],
    ""allowUnsafeCode"": false,
    ""overrideReferences"": false,
    ""precompiledReferences"": [],
    ""autoReferenced"": true,
    ""defineConstraints"": [],
    ""noEngineReferences"": false
}}";
    }
}
#endif
