﻿#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;

public static class CardDefinitionJsonImporter
{
    // JSON 位置（组员脚本一致：Assets/Scripts/Data/Json/card.json）
    private const string JsonRelativePath = "Assets/Scripts/Data/Json/card.json";

    // 生成出来的 CardDefinition 存放目录
    private const string OutputFolder = "Assets/GameData/Cards/";

    [MenuItem("Tools/Card Game/Import CardDefinitions From JSON")]
    public static void Import()
    {
        try
        {
            // 1) 读 JSON
            if (!File.Exists(JsonRelativePath))
            {
                Debug.LogError($"找不到 JSON：{JsonRelativePath}\n请确认文件存在。");
                return;
            }

            var json = File.ReadAllText(JsonRelativePath);
            var wrapper = JsonUtility.FromJson<CardDataWrapper>(json);

            if (wrapper == null || wrapper.allCards == null)
            {
                Debug.LogError("JSON 解析失败：CardDataWrapper 或 allCards 为 null，请检查 card.json 格式。");
                return;
            }

            // 2) 确保输出目录存在
            EnsureFolder(OutputFolder);

            int created = 0;
            int updated = 0;

            // 3) 批量生成/更新 CardDefinition
            foreach (var data in wrapper.allCards)
            {
                if (data == null) continue;

                string idStr = data.id.ToString();
                string safeName = MakeSafeFileName(data.cardName);
                string assetName = $"card_{idStr}_{safeName}.asset";
                string assetPath = $"{OutputFolder}/{assetName}";

                // 尝试按 ID 复用已有资产：如果路径变了也能找到
                CardDefinition def = FindExistingById(idStr);
                if (def == null)
                {
                    def = AssetDatabase.LoadAssetAtPath<CardDefinition>(assetPath);
                }

                bool isNew = false;
                if (def == null)
                {
                    def = ScriptableObject.CreateInstance<CardDefinition>();
                    AssetDatabase.CreateAsset(def, assetPath);
                    isNew = true;
                }

                ApplyDataToDefinition(def, data);

                EditorUtility.SetDirty(def);
                if (isNew) created++;
                else updated++;
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            // 4) 自动把场景里所有 CardDatabase 的 allCards 填好
            AutoAssignToAllCardDatabases();

            Debug.Log($"导入完成：Created={created}, Updated={updated}\n输出目录：{OutputFolder}");
        }
        catch (Exception e)
        {
            Debug.LogException(e);
        }
    }

    private static void ApplyDataToDefinition(CardDefinition def, CardData data)
    {
        // 基础信息
        def.id = data.id.ToString();
        def.displayName = string.IsNullOrWhiteSpace(data.cardName) ? $"Card {data.id}" : data.cardName;
        def.description = data.description;
        def.level = Mathf.Max(0, data.value);

        // tags：按 CardType 做一个“最小可用”的映射
        def.tags = MapTypeToTags(data.cardType);

        // artwork：优先按 Resources 路径加载（iconPath 例如 "Icons/Wood"）
        def.artwork = LoadSpriteFromIconPath(data.iconPath);

        // rarity：先默认 Common（后续你想按 value 或 sellPrice 映射也很容易）
        def.rarity = CardDefinition.CardRarity.Common;
    }

    private static CardTag MapTypeToTags(CardData.CardType type)
    {
        // 这里是“保底映射”：先能跑起来
        // 如果你们后续要细分 Wood/Stone/Metal 等，建议在 JSON 里加 extraTags 字段再扩展解析
        switch (type)
        {
            case CardData.CardType.NaturalResource:
            case CardData.CardType.BioResource:
            case CardData.CardType.Material:
                return CardTag.Material;

            case CardData.CardType.Food:
                return CardTag.Food;

            default:
                return CardTag.None;
        }
    }

    private static Sprite LoadSpriteFromIconPath(string iconPath)
    {
        if (string.IsNullOrWhiteSpace(iconPath))
            return null;

        // 1) Resources.Load（推荐：iconPath 对应 Resources 下的相对路径）
        var s = Resources.Load<Sprite>(iconPath);
        if (s != null) return s;

        // 2) AssetDatabase 兜底：尝试在工程里找同名 Sprite
        // （注意：这会慢一些，但只在导入时跑）
        string fileName = Path.GetFileName(iconPath);
        string[] guids = AssetDatabase.FindAssets($"{fileName} t:Sprite");
        if (guids != null && guids.Length > 0)
        {
            string p = AssetDatabase.GUIDToAssetPath(guids[0]);
            return AssetDatabase.LoadAssetAtPath<Sprite>(p);
        }

        return null;
    }

    private static void AutoAssignToAllCardDatabases()
    {
        // Editor 下可以拿到场景里所有对象（含未激活）
        var dbs = Resources.FindObjectsOfTypeAll<CardDatabase>();
        if (dbs == null || dbs.Length == 0) return;

        // 找到输出目录下所有 CardDefinition
        var defs = LoadAllGeneratedDefinitions();
        foreach (var db in dbs)
        {
            if (db == null) continue;

            db.allCards ??= new List<CardDefinition>();
            db.allCards.Clear();
            db.allCards.AddRange(defs);

            // 让 Inspector/序列化知道它变了
            EditorUtility.SetDirty(db);
        }

        AssetDatabase.SaveAssets();
    }

    private static List<CardDefinition> LoadAllGeneratedDefinitions()
    {
        var list = new List<CardDefinition>();
        string[] guids = AssetDatabase.FindAssets("t:CardDefinition", new[] { OutputFolder });
        foreach (var g in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(g);
            var def = AssetDatabase.LoadAssetAtPath<CardDefinition>(path);
            if (def != null) list.Add(def);
        }

        // 稳定排序（按 id 数字）
        list.Sort((a, b) =>
        {
            int.TryParse(a.id, out var ia);
            int.TryParse(b.id, out var ib);
            return ia.CompareTo(ib);
        });

        return list;
    }

    private static CardDefinition FindExistingById(string idStr)
    {
        // 全工程搜 CardDefinition（只在导入时执行，可接受）
        string[] guids = AssetDatabase.FindAssets("t:CardDefinition");
        foreach (var g in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(g);
            var def = AssetDatabase.LoadAssetAtPath<CardDefinition>(path);
            if (def != null && def.id == idStr)
                return def;
        }
        return null;
    }

    private static void EnsureFolder(string folder)
    {
        // 例如 "Assets/GameData/Cards/Generated"
        if (AssetDatabase.IsValidFolder(folder)) return;

        string[] parts = folder.Split('/');
        string current = parts[0]; // "Assets"
        for (int i = 1; i < parts.Length; i++)
        {
            string next = $"{current}/{parts[i]}";
            if (!AssetDatabase.IsValidFolder(next))
                AssetDatabase.CreateFolder(current, parts[i]);
            current = next;
        }
    }

    private static string MakeSafeFileName(string name)
    {
        if (string.IsNullOrWhiteSpace(name)) return "Unnamed";
        foreach (char c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '_');
        return name.Trim();
    }
}
#endif
