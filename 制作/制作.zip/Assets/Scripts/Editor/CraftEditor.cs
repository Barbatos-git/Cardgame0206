﻿using UnityEditor;
using UnityEngine;
using System.IO;

#if UNITY_EDITOR
[CustomEditor(typeof(CraftData))]
public class CraftEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        CraftData craftDB = (CraftData)target;

        EditorGUILayout.Space();

        if (GUILayout.Button("从 JSON 导入合成数据"))
        {
            ImportCraftData(craftDB);
        }
    }

    private void ImportCraftData(CraftData db)
    {
        // JSON 文件路径：Assets/Scripts/Data/Json/craft.json
        string filePath = Path.Combine(Application.dataPath, "Assets/Scripts/Data/Json/craft.json");

        if (!File.Exists(filePath))
        {
            Debug.LogError("找不到 craft.json 文件，应该放在：Assets/Scripts/Data/Json/craft.json");
            return;
        }

        string json = File.ReadAllText(filePath);

        CraftDataWrapper wrapper = JsonUtility.FromJson<CraftDataWrapper>(json);

        if (wrapper == null || wrapper.recipes == null)
        {
            Debug.LogError("craft.json 格式错误或无法解析");
            return;
        }

        db.recipes = wrapper.recipes;

        EditorUtility.SetDirty(db);
        AssetDatabase.SaveAssets();

        Debug.Log($"成功从 {filePath} 导入 {db.recipes.Count} 条合成配方！");
    }
}
#endif