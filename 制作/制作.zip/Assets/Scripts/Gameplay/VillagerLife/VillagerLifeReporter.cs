using UnityEngine;

[RequireComponent(typeof(VillagerMarker))]
public sealed class VillagerLifeReporter : MonoBehaviour
{
    private bool _registered;

    private void Start()
    {
        if (VillagerLifeTracker.Instance != null)
        {
            VillagerLifeTracker.Instance.RegisterVillager(gameObject);
            _registered = true;
        }
    }

    private void OnDestroy()
    {
        if (_registered && VillagerLifeTracker.Instance != null)
        {
            VillagerLifeTracker.Instance.UnregisterVillager(gameObject);
        }
    }
}
