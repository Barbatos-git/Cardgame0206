using UnityEngine;

public sealed class VillagerMarker : MonoBehaviour { }
