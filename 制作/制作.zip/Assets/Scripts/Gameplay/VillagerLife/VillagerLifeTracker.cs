using CardGame.Gameplay.Units;
using System.Collections.Generic;
using UnityEngine;

public sealed class VillagerLifeTracker : MonoBehaviour, IResettable
{
    public static VillagerLifeTracker Instance { get; private set; }

    private readonly HashSet<CharacterCard> _alive = new();

    private readonly HashSet<int> _aliveVillagerInstanceIds = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    private void Start()
    {
        // 进入 GameScene 时，先扫描场上已有的村民（例如开局生成的2个村民）
        ScanAndRegisterExistingVillagers();
        CheckGameOver();
    }

    public void RegisterVillager(GameObject villagerGo)
    {
        if (villagerGo == null) return;
        _aliveVillagerInstanceIds.Add(villagerGo.GetInstanceID());
    }

    public void UnregisterVillager(GameObject villagerGo)
    {
        if (villagerGo == null) return;
        _aliveVillagerInstanceIds.Remove(villagerGo.GetInstanceID());
        CheckGameOver();
    }

    private void CheckGameOver()
    {
        // 只在 GameScene 中判断更安全，但这里简单处理：数量归零就结束
        if (_aliveVillagerInstanceIds.Count <= 0)
        {
            SceneFlow.Instance?.GameOver();
        }
    }

    private void ScanAndRegisterExistingVillagers()
    {
        var markers = FindObjectsOfType<VillagerMarker>(true);
        foreach (var m in markers)
        {
            RegisterVillager(m.gameObject);
        }
    }

    public void Register(CharacterCard card)
    {
        _alive.Add(card);
    }

    public void Unregister(CharacterCard card)
    {
        _alive.Remove(card);
    }

    public bool HasAliveVillagers => _alive.Count > 0;

    public void ResetState()
    {
        // 清运行时缓存
        _alive.Clear();
        _aliveVillagerInstanceIds.Clear();

        StopAllCoroutines();

        // 清单例
        if (Instance == this)
            Instance = null;
    }
}
