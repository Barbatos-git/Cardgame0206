using UnityEngine;

public sealed class CardNameTextMarker : MonoBehaviour { }
