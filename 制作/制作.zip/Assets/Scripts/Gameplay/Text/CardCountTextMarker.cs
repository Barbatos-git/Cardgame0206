using UnityEngine;

public sealed class CardCountTextMarker : MonoBehaviour{ }
