﻿using UnityEngine;
using CardGame.Core.Pause;

namespace CardGame.Gameplay.Pause
{
    /// <summary>
    /// 暂停时：把场景里所有实现 IPausable 的行为暂停。
    /// 注意：这只暂停“进行中的任务”，不会影响 UI、拖拽等。
    /// </summary>
    public class PauseDispatcher : MonoBehaviour
    {
        private void OnEnable()
        {
            PauseEvents.OnPauseChanged += ApplyPause;
        }

        private void OnDisable()
        {
            PauseEvents.OnPauseChanged -= ApplyPause;
        }

        private void ApplyPause(bool paused)
        {
            // 简单粗暴版：找到场景中所有 MonoBehaviour，筛选出 IPausable
            var behaviours = FindObjectsOfType<MonoBehaviour>(true);
            foreach (var b in behaviours)
            {
                if (b is IPausable p)
                {
                    if (paused) p.Pause();
                    else p.Resume();
                }
            }
        }
    }
}
