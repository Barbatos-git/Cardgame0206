﻿using UnityEngine;
using CardGame.Core.Pause;

namespace CardGame.Gameplay.Pause
{
    /// <summary>
    /// 全局暂停服务：
    /// - 不使用 Time.timeScale（避免 UI/拖拽/你自己的逻辑被 Unity 一刀切影响）
    /// - 只通过事件通知各系统“该不该跑”
    /// </summary>
    public class PauseSystem : MonoBehaviour, IPauseService
    {
        public bool IsPaused { get; private set; }

        [SerializeField] private bool allowEscToggle = true;

        private void Update()
        {
            if (!allowEscToggle) return;

            if (Input.GetKeyDown(KeyCode.Escape))
                Toggle();
        }

        public void Toggle() => SetPaused(!IsPaused);

        public void SetPaused(bool paused)
        {
            if (IsPaused == paused) return;
            IsPaused = paused;
            PauseEvents.RaisePauseChanged(IsPaused);
        }
    }
}
