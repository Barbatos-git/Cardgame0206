﻿using System;
using UnityEngine;

/// <summary>
/// 开局生成初始卡牌：合成台(601) + 村民x2 + 山菜x2 + 斧子x1
/// 关键：生成后必须调用 CardWorldView.Setup(def)，让 CardBehaviorInstaller 自动安装身份。
/// </summary>
public sealed class GameStartCardSpawner : MonoBehaviour
{
    [Header("Card Prefab (通用卡牌 prefab)")]
    [SerializeField] private GameObject cardPrefab;

    [Header("Spawn Area (世界坐标范围)")]
    [SerializeField] private Vector2 center = Vector2.zero;
    [SerializeField] private float radius = 1.2f;

    [Header("Initial Card IDs")]
    [SerializeField] private string fusionTableId = "601";
    [SerializeField] private string villagerId = "801"; 
    [SerializeField] private string wildPlantId = "302"; 
    [SerializeField] private string axeId = "501"; 

    [Header("Counts")]
    [SerializeField] private int villagerCount = 2;
    [SerializeField] private int wildPlantCount = 2;
    [SerializeField] private int axeCount = 1;

    [Header("Options")]
    [SerializeField] private bool runOnce = true;

    private bool _ran;

    private void Start()
    {
        if (runOnce && _ran) return;
        _ran = true;

        if (cardPrefab == null)
        {
            Debug.LogError("[GameStartCardSpawner] cardPrefab 未设置（通用卡牌prefab）", this);
            return;
        }

        // 生成顺序：先合成台，确保合成区尽早出现
        SpawnCardById(fusionTableId);

        for (int i = 0; i < villagerCount; i++) SpawnCardById(villagerId);
        for (int i = 0; i < wildPlantCount; i++) SpawnCardById(wildPlantId);
        for (int i = 0; i < axeCount; i++) SpawnCardById(axeId);
    }

    private void SpawnCardById(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            Debug.LogError("[GameStartCardSpawner] card id is empty.", this);
            return;
        }

        var def = GetDefById(id);
        if (def == null)
        {
            Debug.LogError($"[GameStartCardSpawner] CardDefinition not found: {id}", this);
            return;
        }

        var pos = SamplePos();
        var go = Instantiate(cardPrefab, new Vector3(pos.x, pos.y, 0f), Quaternion.identity);

        var view = go.GetComponent<CardWorldView>();
        if (view == null)
        {
            Debug.LogError("[GameStartCardSpawner] cardPrefab 缺少 CardWorldView 组件", go);
            Destroy(go);
            return;
        }

        view.Setup(def); // 触发 Installer -> 身份/Spawner
    }

    private Vector2 SamplePos()
    {
        // 简单圆形散布，避免完全重叠
        var offset = UnityEngine.Random.insideUnitCircle * radius;
        return center + offset;
    }

    // 这里只需要对接项目的数据库入口
    private CardDefinition GetDefById(string id)
    {
        // 如果项目里是 CardDatabase.Instance.GetCardById(id) 就直接用
        // 如果项目里是某个 GameManager 持有 db，也可以改成从那里取
        try
        {
            return CardDatabase.Instance.GetCardById(id);
        }
        catch (Exception e)
        {
            Debug.LogError($"[GameStartCardSpawner] CardDatabase access failed. Please adjust GetDefById() to match your project. {e.Message}", this);
            return null;
        }
    }
}
