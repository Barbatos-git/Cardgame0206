﻿using UnityEngine;
using CardGame.Core.Time;
using CardGame.Data.Time;
using CardGame.Core.Pause;

namespace CardGame.Gameplay.Time
{
    /// <summary>
    /// 时间系统（Gameplay）：
    /// - 行为驱动：外部调用 AddTick()
    /// - 或自动驱动：autoTick=true 时 Update 内累积
    /// </summary>
    public class TimeSystem : MonoBehaviour, ITimeService
    {
        [SerializeField] private TimeConfigSO config;

        public int CurrentDay { get; private set; } = 1;
        public int CurrentTick { get; private set; } = 0;
        public int TicksPerDay => config != null ? config.ticksPerDay : 60;

        private float _acc;

        private void Update()
        {
            if (_paused) return;
            if (config == null || !config.autoTick) return;

            _acc += UnityEngine.Time.deltaTime;
            if (_acc >= config.secondsPerTick)
            {
                _acc -= config.secondsPerTick;
                AddTick(1);
            }
        }

        public void AddTick(int amount = 1)
        {
            if (amount <= 0) return;

            CurrentTick += amount;

            while (CurrentTick >= TicksPerDay)
            {
                CurrentTick -= TicksPerDay;
                EndDayInternal();
            }
        }

        public void ForceEndDay()
        {
            EndDayInternal();
        }

        private void EndDayInternal()
        {
            // 约定：先触发 DayEnded（当天号）→ 再 day++ → DayChanged（新天号）
            TimeEvents.RaiseDayEnded(CurrentDay);
            CurrentDay++;
            TimeEvents.RaiseDayChanged(CurrentDay);
        }

        private bool _paused;

        private void OnEnable()
        {
            PauseEvents.OnPauseChanged += OnPauseChanged;
        }

        private void OnDisable()
        {
            PauseEvents.OnPauseChanged -= OnPauseChanged;
        }

        private void OnPauseChanged(bool isPaused)
        {
            _paused = isPaused;
        }

    }
}
