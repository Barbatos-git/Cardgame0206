﻿using UnityEngine;
using CardGame.Core.Resources;

namespace CardGame.Gameplay.Resources
{
    public sealed class FoodCountBroadcaster : MonoBehaviour
    {
        [SerializeField] private float pollInterval = 0.2f;

        [Header("Count Rules")]
        [SerializeField] private bool onlyCountRootCards = true;
        [SerializeField] private bool skipDraggingRoots = true;
        [SerializeField] private bool skipFusionZoneRoots = true;

        [Header("Stability")]
        // 拖拽中冻结UI，不闪烁
        [SerializeField] private bool freezeBroadcastWhileDragging = true; 

        private float _pollTimer;
        private int _lastCount = int.MinValue;

        private void OnEnable()
        {
            _pollTimer = 0f;
            ForceBroadcast();
        }

        private void Update()
        {
            _pollTimer += UnityEngine.Time.deltaTime;
            if (_pollTimer < pollInterval) return;

            _pollTimer = 0f;

            // 只要场上有人在拖拽（root），就保持上次值，不做 -1/+1 闪烁
            if (freezeBroadcastWhileDragging && HasAnyDraggingRoot())
                return;

            int cur = CountFoodOnField();
            if (cur == _lastCount) return;

            _lastCount = cur;
            ResourceEvents.RaiseChanged(ResourceType.Food, cur);
        }

        public void ForceBroadcast()
        {
            int cur = CountFoodOnField();
            _lastCount = cur;
            ResourceEvents.RaiseChanged(ResourceType.Food, cur);
        }

        private bool HasAnyDraggingRoot()
        {
            var list = CardWorldView.CardWorldViewRegistry;

            for (int i = 0; i < list.Count; i++)
            {
                var v = list[i];
                if (v == null) continue;

                var root = v.GetStackRoot();
                if (root == null) continue;

                // 只检查 root（避免每张成员重复判断）
                if (root != v) continue;

                if (root.IsDraggingRoot)
                    return true;
            }
            return false;
        }

        private int CountFoodOnField()
        {
            int count = 0;
            var list = CardWorldView.CardWorldViewRegistry;

            for (int i = 0; i < list.Count; i++)
            {
                var card = list[i];
                if (card == null || card.definition == null) continue;

                // 用 root 的状态来做过滤（拖拽 / 合成区）
                var root = card.GetStackRoot();
                if (skipDraggingRoots && root != null && root.IsDraggingRoot) continue;
                if (skipFusionZoneRoots && root != null && root.isInFusionZone) continue;

                // ✅ 按“卡片”统计，而不是按“堆”统计
                if (card.definition.tags.HasFlag(CardTag.Food))
                    count++;
            }

            return count;
        }

    }
}
