﻿using System.Collections.Generic;
using UnityEngine;
using CardGame.Core.Time;
using CardGame.Core.Resources;
using CardGame.Gameplay.Units;
using DG.Tweening;


namespace CardGame.Gameplay.Food
{
    public class FoodSettlementSystem : MonoBehaviour
    {
        [Header("Rule")]
        [Min(0)]
        [SerializeField] private int foodPerUnitPerDay = 1;

        [Header("Scan Rules")]
        [SerializeField] private bool onlyCountRootCards = true;
        [SerializeField] private bool skipDraggingRoots = true;
        [SerializeField] private bool skipFusionZoneRoots = true;

        private void OnEnable()
        {
            TimeEvents.OnDayEnded += HandleDayEnded;

            ResourceEvents.RaiseChanged(ResourceType.Food, CountFoodOnField());
        }

        private void OnDisable()
        {
            TimeEvents.OnDayEnded -= HandleDayEnded;
        }

        private void HandleDayEnded(int day)
        {
            int population = CountAliveCharacters();
            int requiredFood = population * foodPerUnitPerDay;
            int availableFood = CountFoodOnField();

            Debug.Log($"[Food] Day {day} 结算：人口={population}, 需求={requiredFood}, 现有={availableFood}");

            if (requiredFood <= 0)
            {
                BroadcastFoodCount();
                return;
            }

            if (availableFood >= requiredFood)
            {
                ConsumeFoodCards(requiredFood);
            }
            else
            {
                // 先吃光所有食物
                if (availableFood > 0)
                    ConsumeFoodCards(availableFood);

                int shortage = requiredFood - availableFood;

                // 缺多少份，就死多少人（但不超过现有人口）
                KillCharacters(shortage);

                Debug.LogWarning($"[Food] Day {day}：食物不足，已处决 {shortage} 人（最多不超过现有人口）");
            }

            BroadcastFoodCount();
        }

        // =========================
        // Population
        // =========================
        private int CountAliveCharacters()
        {
            // 临时关闭“跳过合成区”
            bool oldSkip = skipFusionZoneRoots;
            skipFusionZoneRoots = false;

            int count = 0;
            foreach (var root in CollectAliveCharacterRoots())
            {
                count++;
            }

            // 恢复原设置
            skipFusionZoneRoots = oldSkip;

            return count;
        }

        private List<CardWorldView> CollectAliveCharacterRoots()
        {
            var result = new List<CardWorldView>(16);
            var list = CardWorldView.CardWorldViewRegistry;

            for (int i = 0; i < list.Count; i++)
            {
                var v = list[i];
                if (v == null || v.definition == null) continue;

                var root = v.GetStackRoot();
                if (onlyCountRootCards && root != v) continue;

                if (skipDraggingRoots && root.IsDraggingRoot) continue;
                if (skipFusionZoneRoots && root.isInFusionZone) continue;

                if (!root.definition.tags.HasFlag(CardTag.Character)) continue;

                var cc = root.GetComponent<CharacterCard>();
                if (cc == null || cc.IsDead) continue;

                result.Add(root);
            }

            return result;
        }

        // =========================
        // Food
        // =========================
        private int CountFoodOnField()
        {
            int count = 0;
            var list = CardWorldView.CardWorldViewRegistry;

            for (int i = 0; i < list.Count; i++)
            {
                var v = list[i];
                if (v == null || v.definition == null) continue;

                var root = v.GetStackRoot();

                // 只统计 root，避免一堆被数多次
                if (root != v) continue;

                if (skipDraggingRoots && root.IsDraggingRoot) continue;
                if (skipFusionZoneRoots && root.isInFusionZone) continue;

                // 遍历整堆成员（包括 root 和堆内卡）
                foreach (var c in root.GetStackMembersIncludingSelf())
                {
                    if (c == null || c.definition == null) continue;
                    if (c.definition.tags.HasFlag(CardTag.Food))
                        count++;
                }
            }

            return count;
        }

        private void ConsumeFoodCards(int amount)
        {
            if (amount <= 0) return;

            // 1) 收集所有“食物堆 root”（只处理 root，避免重复）
            //    这里默认“食物堆”= root 也是 Food，且该堆成员全是 Food（更稳）
            var roots = new List<CardWorldView>(32);
            var list = CardWorldView.CardWorldViewRegistry;

            for (int i = 0; i < list.Count; i++)
            {
                var v = list[i];
                if (v == null || v.definition == null) continue;

                var root = v.GetStackRoot();
                if (root != v) continue; // 只收 root

                if (skipDraggingRoots && root.IsDraggingRoot) continue;
                if (skipFusionZoneRoots && root.isInFusionZone) continue;

                // 只从“食物堆”消耗：root 必须是 Food
                if (!root.definition.tags.HasFlag(CardTag.Food)) continue;

                // 可选：要求整堆都是 Food（避免你把 Food 堆到别的卡上造成误吃）
                if (!IsAllFoodStack(root)) continue;

                roots.Add(root);
            }

            // 2) 从每个 root 的“顶端”开始 pop，直到吃够 amount
            int remaining = amount;

            for (int r = 0; r < roots.Count && remaining > 0; r++)
            {
                var root = roots[r];
                if (root == null) continue;

                // 这堆没有成员列表，说明是单卡或数据异常；兜底当 1 张处理
                int stackCount = GetStackCountSafe(root);

                if (stackCount <= 0) continue;

                int eatHere = Mathf.Min(remaining, stackCount);

                // 从顶牌开始移除 eatHere 张
                PopFromTopAndDestroy(root, eatHere);

                // 吃完这堆后，刷新该堆视觉/成员关系（关键）
                RefreshStackVisualAfterSplit_Safe(root);

                remaining -= eatHere;
            }

            // 如果 remaining > 0 说明场上食物不足（上层逻辑会处理缺粮）
        }


        // =========================
        // ★ NEW：Starvation = Death
        // =========================
        private void KillCharacters(int shortage)
        {
            if (shortage <= 0) return;

            var characters = CollectAliveCharacterRoots();
            int toKill = Mathf.Min(shortage, characters.Count);

            for (int i = 0; i < toKill; i++)
            {
                var victim = characters[i];
                if (victim == null) continue;

                Debug.LogWarning($"[Food] 饥饿致死：{victim.name}");
                Destroy(victim.gameObject);
            }
        }

        private void BroadcastFoodCount()
        {
            ResourceEvents.RaiseChanged(ResourceType.Food, CountFoodOnField());
        }

        private int GetStackCountSafe(CardWorldView root)
        {
            if (root == null) return 0;

            // 约定：stackMembers.Count 表示“包含 root 在内的总数”
            if (root.stackMembers != null && root.stackMembers.Count > 0)
                return root.stackMembers.Count;

            // 没成员列表就当单卡
            return 1;
        }

        private bool IsAllFoodStack(CardWorldView root)
        {
            if (root == null) return false;

            // 单卡
            if (root.stackMembers == null || root.stackMembers.Count == 0)
                return root.definition != null && root.definition.tags.HasFlag(CardTag.Food);

            for (int i = 0; i < root.stackMembers.Count; i++)
            {
                var c = root.stackMembers[i];
                if (c == null || c.definition == null) return false;
                if (!c.definition.tags.HasFlag(CardTag.Food)) return false;
            }
            return true;
        }

        /// <summary>
        /// 从顶端弹出并销毁若干张卡（只修改 root.stackMembers，不做视觉刷新）
        /// </summary>
        private void PopFromTopAndDestroy(CardWorldView root, int count)
        {
            if (root == null || count <= 0) return;

            // 单卡：直接 Destroy root
            if (root.stackMembers == null || root.stackMembers.Count == 0)
            {
                Destroy(root.gameObject);
                return;
            }

            // 确保 root 在 stackMembers[0]
            if (root.stackMembers[0] != root)
            {
                int idx = root.stackMembers.IndexOf(root);
                if (idx >= 0)
                {
                    root.stackMembers.RemoveAt(idx);
                    root.stackMembers.Insert(0, root);
                }
            }

            for (int k = 0; k < count; k++)
            {
                if (root.stackMembers == null || root.stackMembers.Count <= 0) break;

                // 如果只剩 root 这一张，销毁 root 并退出
                if (root.stackMembers.Count == 1)
                {
                    Destroy(root.gameObject);
                    return;
                }

                // 弹出顶牌：最后一个元素
                int last = root.stackMembers.Count - 1;
                var top = root.stackMembers[last];

                // 从成员表移除
                root.stackMembers.RemoveAt(last);

                if (top != null)
                {
                    // 断开引用（避免其它系统误认为它还在堆里）
                    top.stackRoot = top;
                    top.stackMembers = null;

                    Destroy(top.gameObject);
                }
            }
        }

        /// <summary>
        /// 复制你给的 RefreshStackVisualAfterSplit 逻辑（做了少量兜底）
        /// </summary>
        private void RefreshStackVisualAfterSplit_Safe(CardWorldView root)
        {
            if (root == null) return;

            // root 可能被 Destroy（单卡被吃掉时）
            if (root.gameObject == null) return;

            // 已经变成单卡（或成员列表为空）
            if (root.stackMembers == null || root.stackMembers.Count <= 1)
            {
                var disp0 = root.GetComponent<CardStackDisplay>();
                if (disp0 != null)
                {
                    disp0.ShowAsBottom(root.transform.position);
                    disp0.SetCount(0);
                }
                return;
            }

            // 确保 root 在 stackMembers[0]
            if (root.stackMembers[0] != root)
            {
                int idx = root.stackMembers.IndexOf(root);
                if (idx >= 0)
                {
                    root.stackMembers.RemoveAt(idx);
                    root.stackMembers.Insert(0, root);
                }
            }

            int totalCount = root.stackMembers.Count;
            Vector3 center = root.transform.position;

            // 所有成员 stackRoot 指向 root；非根不维护成员列表
            for (int i = 0; i < root.stackMembers.Count; i++)
            {
                var c = root.stackMembers[i];
                if (c == null) continue;

                c.stackRoot = root;
                if (c != root) c.stackMembers = null;
            }

            // 刷新视觉：底/中/顶
            for (int i = 0; i < root.stackMembers.Count; i++)
            {
                var c = root.stackMembers[i];
                if (c == null) continue;

                c.transform.DOComplete();

                var disp = c.GetComponent<CardStackDisplay>();
                if (disp == null) continue;

                bool isBottom = (i == 0);
                bool isTop = (i == root.stackMembers.Count - 1);

                if (isBottom)
                {
                    c.offsetInStack = Vector3.zero;
                    disp.ShowAsBottom(center);
                    disp.SetCount(0); // 数量显示放在顶牌上
                }
                else if (isTop)
                {
                    c.offsetInStack = new Vector3(disp.topOffset.x, disp.topOffset.y, 0f);
                    disp.ShowAsTop(center);
                    disp.SetCount(totalCount);
                }
                else
                {
                    c.offsetInStack = Vector3.zero;
                    disp.HideInStack(center);
                }

                c.transform.position = center + c.offsetInStack;
            }

            // 排序稳定化：简单版（如果你项目里有更完整的 ApplyStackSorting，可替换这里）
            int baseOrder = (root.artworkRenderer != null) ? root.artworkRenderer.sortingOrder : 0;
            ApplyStackSorting_Simple(root, baseOrder);

            root.ClampStackToNormalArea();
        }

        private void ApplyStackSorting_Simple(CardWorldView root, int baseOrder)
        {
            if (root == null) return;

            // 单卡
            if (root.stackMembers == null || root.stackMembers.Count == 0)
            {
                if (root.artworkRenderer != null) root.artworkRenderer.sortingOrder = baseOrder;
                return;
            }

            // 从底到顶递增
            for (int i = 0; i < root.stackMembers.Count; i++)
            {
                var c = root.stackMembers[i];
                if (c == null) continue;

                if (c.artworkRenderer != null)
                    c.artworkRenderer.sortingOrder = baseOrder + i;
            }
        }
    }
}
