﻿using System.Collections.Generic;
using UnityEngine;
using CardGame.Core.Resources;

namespace CardGame.Gameplay.Resources
{
    public class SimpleResourceStore : MonoBehaviour, IResourceStore
    {
        private readonly Dictionary<ResourceType, int> _map = new();

        public int Get(ResourceType type)
        {
            return _map.TryGetValue(type, out var v) ? v : 0;
        }

        public void Add(ResourceType type, int amount)
        {
            if (amount <= 0) return;
            int newV = Get(type) + amount;
            _map[type] = newV;
            ResourceEvents.RaiseChanged(type, newV);
        }

        public bool TryConsume(ResourceType type, int amount)
        {
            if (amount <= 0) return true;
            int cur = Get(type);
            if (cur < amount) return false;

            int newV = cur - amount;
            _map[type] = newV;
            ResourceEvents.RaiseChanged(type, newV);
            return true;
        }
    }
}
