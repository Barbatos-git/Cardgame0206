﻿using UnityEngine;

[RequireComponent(typeof(Camera))]
public class WorldCameraController : MonoBehaviour
{
    [Header("缩放设置")]
    public float zoomSpeed = 2f;
    public float minSize = 3f;
    public float maxSize = 15f;

    [Header("平移设置")]
    // 鼠标拖动灵敏度
    public float panSpeed = 1f;  
    // x,y 为左下角坐标，width/height 为宽高，在Inspector可调
    public Rect cameraBounds = new Rect(-38f, -20f, 76f, 40f);

    private Camera cam;
    private bool isPanning = false;
    private Vector3 lastMousePos;

    private void Awake()
    {
        cam = GetComponent<Camera>();
        // 确保是正交相机
        cam.orthographic = true; 
    }

    private void Update()
    {
        HandleZoom();
        HandlePan();
    }

    private void HandleZoom()
    {
        float scroll = Input.mouseScrollDelta.y;
        if (Mathf.Abs(scroll) > 0.01f)
        {
            cam.orthographicSize = Mathf.Clamp(
                cam.orthographicSize - scroll * zoomSpeed,
                minSize,
                maxSize
            );
            ClampCameraPosition();
        }
    }

    private void HandlePan()
    {
        // 右键拖动平移世界
        if (Input.GetMouseButtonDown(1))
        {
            isPanning = true;
            lastMousePos = Input.mousePosition;
        }

        if (Input.GetMouseButton(1) && isPanning)
        {
            Vector3 mousePos = Input.mousePosition;
            Vector3 delta = mousePos - lastMousePos;
            lastMousePos = mousePos;

            // 屏幕像素偏移 → 世界坐标偏移
            // 对于正交相机：世界偏移 ~ 像素偏移 * (orthSize*2 / Screen.height)
            float factor = cam.orthographicSize * 2f / Screen.height * panSpeed;
            Vector3 move = new Vector3(-delta.x * factor, -delta.y * factor, 0f);

            transform.position += move;
            ClampCameraPosition();
        }

        if (Input.GetMouseButtonUp(1))
        {
            isPanning = false;
        }
    }

    private void ClampCameraPosition()
    {
        if (cameraBounds.width <= 0f || cameraBounds.height <= 0f)
            return;

        float vertExtent = cam.orthographicSize;
        float horExtent = vertExtent * cam.aspect;

        // 计算相机中心允许的范围（保证视野不超出边界）
        float minX = cameraBounds.xMin + horExtent;
        float maxX = cameraBounds.xMax - horExtent;
        float minY = cameraBounds.yMin + vertExtent;
        float maxY = cameraBounds.yMax - vertExtent;

        Vector3 pos = transform.position;
        pos.x = Mathf.Clamp(pos.x, minX, maxX);
        pos.y = Mathf.Clamp(pos.y, minY, maxY);
        transform.position = pos;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Vector3 center = new Vector3(
            cameraBounds.x + cameraBounds.width * 0.5f,
            cameraBounds.y + cameraBounds.height * 0.5f,
            0f
        );
        Vector3 size = new Vector3(cameraBounds.width, cameraBounds.height, 0f);
        Gizmos.DrawWireCube(center, size);
    }
}

