using UnityEngine;

public sealed class QuitOnEsc : MonoBehaviour
{
    [Header("Key")]
    [SerializeField] private KeyCode quitKey = KeyCode.Escape;

    [Header("Options")]
    [SerializeField] private bool onlyInBuild = true;

    void Update()
    {
        if (!Input.GetKeyDown(quitKey)) return;

#if UNITY_EDITOR
        if (onlyInBuild) return; // Editor 不退出（避免开发时误关）
#endif

        Application.Quit();
    }
}
