﻿public static class TaskConditionChecker
{
    public static bool Check(TaskCondition condition)
    {
        var tm = TaskManager.Instance;
        if (tm == null) return false;

        switch (condition.type)
        {
            case TaskConditionType.HaveCard:
                return tm.GetCardCount(condition.targetId) >= condition.count;

            case TaskConditionType.CraftCard:
                return tm.GetCraftCount(condition.targetId) >= condition.count;

            default:
                return false;
        }
    }
}
