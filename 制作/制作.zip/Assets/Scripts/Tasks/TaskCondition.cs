﻿using System;
using System.Collections.Generic;

[Serializable]
public class TaskCondition
{
    public TaskConditionType type;
    public int targetId;   // cardId / craftResultId
    public int count;
}

public enum TaskConditionType
{
    HaveCard,
    CraftCard
}

[Serializable]
public class TaskData
{
    public string id;
    public string title;
    public string description;
    public List<TaskCondition> conditions;
}
