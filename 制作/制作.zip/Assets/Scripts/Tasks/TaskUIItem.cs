﻿using TMPro;
using UnityEngine;

public class TaskUIItem : MonoBehaviour
{
    public TextMeshProUGUI titleText;
    public TextMeshProUGUI descriptionText;
    public GameObject completedMark;

    public void Setup(TaskData task, bool completed)
    {
        titleText.text = task.title;
        descriptionText.text = task.description;
        completedMark.SetActive(completed);
    }

    public void SetCompleted(bool completed)
    {
        completedMark.SetActive(completed);
    }
}
