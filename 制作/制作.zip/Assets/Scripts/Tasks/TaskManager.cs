﻿using UnityEngine;
using System.Collections.Generic;
using System.IO;

public class TaskManager : MonoBehaviour
{
    public static TaskManager Instance;
    public event System.Action<string> OnTaskCompleted;

    // ===== JSON Wrapper =====
    [System.Serializable]
    class TaskWrapper
    {
        public List<TaskData> tasks;
    }

    // ===== Runtime Data =====
    public List<TaskData> activeTasks = new();
    private HashSet<string> completedTaskIds = new();

    // ===== Task System State Cache =====
    private Dictionary<int, int> cardCountCache = new();
    private Dictionary<int, int> craftCountCache = new();

    void Awake()
    {
        Instance = this;
        LoadTasks();
    }

    // =================================================
    // 外部通知接口
    // =================================================

    public void NotifyCardChanged(int cardId, int currentCount)
    {
        cardCountCache[cardId] = currentCount;
        CheckAllTasks();
    }

    public void NotifyCrafted(int resultCardId, int totalCraftedCount)
    {
        craftCountCache[resultCardId] = totalCraftedCount;
        CheckAllTasks();
    }

    // =================================================
    // 查询接口（给 TaskConditionChecker）
    // =================================================

    public int GetCardCount(int cardId)
    {
        return cardCountCache.TryGetValue(cardId, out var v) ? v : 0;
    }

    public int GetCraftCount(int cardId)
    {
        return craftCountCache.TryGetValue(cardId, out var v) ? v : 0;
    }

    // =================================================
    // Task Check Logic（唯一完成入口）
    // =================================================

    void CheckAllTasks()
    {
        foreach (var task in activeTasks)
        {
            if (completedTaskIds.Contains(task.id))
                continue;

            if (IsTaskCompleted(task))
            {
                completedTaskIds.Add(task.id);
                Debug.Log($"【任务完成】{task.title}");
                OnTaskCompleted?.Invoke(task.id);
            }
        }
    }

    bool IsTaskCompleted(TaskData task)
    {
        foreach (var condition in task.conditions)
        {
            if (!TaskConditionChecker.Check(condition))
                return false;
        }
        return true;
    }

    // =================================================
    // Load JSON
    // =================================================

    void LoadTasks()
    {
        string path = Path.Combine(Application.streamingAssetsPath, "tasks.json");
        if (!File.Exists(path))
        {
            Debug.LogError("tasks.json not found");
            return;
        }

        string json = File.ReadAllText(path);
        TaskWrapper wrapper = JsonUtility.FromJson<TaskWrapper>(json);

        activeTasks = wrapper.tasks;

        // 开局检查一次
        CheckAllTasks();
    }

    // =================================================
    // UI 查询接口
    // =================================================

    public bool IsTaskCompletedForUI(string taskId)
    {
        return completedTaskIds.Contains(taskId);
    }
}
