using UnityEngine;
using System.Collections.Generic;

public class TaskUIManager : MonoBehaviour
{
    public TaskUIItem taskItemPrefab;
    public Transform contentParent;

    private Dictionary<string, TaskUIItem> taskUIMap = new();

    void Start()
    {
        RefreshAll();
    }

    void OnEnable()
    {
        TaskManager.Instance.OnTaskCompleted += OnTaskCompleted;
    }

    void OnDisable()
    {
        TaskManager.Instance.OnTaskCompleted -= OnTaskCompleted;
    }

    public void RefreshAll()
    {
        foreach (Transform child in contentParent)
            Destroy(child.gameObject);

        taskUIMap.Clear();

        foreach (var task in TaskManager.Instance.activeTasks)
        {
            var item = Instantiate(taskItemPrefab, contentParent);
            bool completed = TaskManager.Instance.IsTaskCompletedForUI(task.id);
            item.Setup(task, completed);

            taskUIMap.Add(task.id, item);
        }
    }

    public void OnTaskCompleted(string taskId)
    {
        if (taskUIMap.TryGetValue(taskId, out var item))
        {
            item.SetCompleted(true);
        }
    }
}
