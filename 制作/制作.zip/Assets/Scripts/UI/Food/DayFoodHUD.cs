﻿using UnityEngine;
using TMPro;
using CardGame.Core.Time;
using CardGame.Core.Resources;

namespace CardGame.UI.HUD
{
    public sealed class DayFoodHUD : MonoBehaviour
    {
        [Header("UI References")]
        [SerializeField] private TMP_Text dayText;
        [SerializeField] private TMP_Text foodText;

        [Header("Format")]
        [SerializeField] private string dayFormat = "Day {0}";
        [SerializeField] private string foodFormat = "Food x {0}";

        // cached state (UI-side)
        private int _day = 1;
        private int _food = 0;

        private void Awake()
        {
            // 可选：Awake 时先画一次（防止启用瞬间空白）
            Refresh();
        }

        private void OnEnable()
        {
            // 订阅事件：由系统广播来驱动 UI
            TimeEvents.OnDayChanged += OnDayChanged;
            ResourceEvents.OnResourceChanged += OnResourceChanged;

            // 关键：启用时刷新一次（显示缓存值）
            // 真正的初始 food 值需要 Gameplay 在启动时 RaiseChanged(Food, count)
            Refresh();
        }

        private void OnDisable()
        {
            TimeEvents.OnDayChanged -= OnDayChanged;
            ResourceEvents.OnResourceChanged -= OnResourceChanged;
        }

        private void OnDayChanged(int newDay)
        {
            _day = Mathf.Max(1, newDay);
            Refresh();
        }

        private void OnResourceChanged(ResourceType type, int newValue)
        {
            if (type != ResourceType.Food) return;

            _food = Mathf.Max(0, newValue);
            Refresh();
        }

        private void Refresh()
        {
            if (dayText != null)
                dayText.text = string.Format(dayFormat, _day);

            if (foodText != null)
                foodText.text = string.Format(foodFormat, _food);
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            // 在 Inspector 改格式 / 绑引用时，编辑器里也能立刻看到效果（不运行也会刷新一次）
            if (!UnityEditor.EditorApplication.isPlayingOrWillChangePlaymode)
                Refresh();
        }
#endif
    }
}
