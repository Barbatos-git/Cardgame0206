﻿using UnityEngine;
using System.Collections;

public class test : MonoBehaviour
{
    public GameObject fusionAreaPrefab;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ClickTest() {
        var area = Instantiate(fusionAreaPrefab);
        var item = area.GetComponent<FusionAreaExpanderItem>();
        var rack = FindObjectOfType<FusionAreaRackManager>();
        if (!rack.TryRegister(item))
        {
            Debug.LogWarning("[TEST] Rack 已满：本次生成的 FusionArea 将被销毁");
            Destroy(area);
        }
        rack.Register(item);
    }
}
