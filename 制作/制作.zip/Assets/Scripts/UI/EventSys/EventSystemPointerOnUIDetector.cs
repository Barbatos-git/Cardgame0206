using UnityEngine;
using UnityEngine.EventSystems;

public class EventSystemPointerOnUIDetector : MonoBehaviour, IPointerOnUIDetector
{
    private void Awake()
    {
        InputGuard.Detector = this;
    }

    public bool IsPointerOnUI()
    {
        return EventSystem.current != null &&
               EventSystem.current.IsPointerOverGameObject();
    }
}
