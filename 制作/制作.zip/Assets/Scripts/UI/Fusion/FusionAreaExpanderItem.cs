﻿using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using TMPro;

/// <summary>
/// 单个 FusionArea 的展开/收起控制（抽屉式）
/// - 运行时自动创建 Toggle(+/×)按钮并绑定
/// - Toggle 按钮跟随 tabAnchorWorldPos（普通区边缘锚点）
/// - 点击后使用 DOTween 在世界坐标滑出/滑回
/// </summary>
public class FusionAreaExpanderItem : MonoBehaviour
{
    [Header("合成区根对象（移动它）")]
    [SerializeField] private Transform fusionAreaRoot;

    [Header("合成区Collider（可在子物体上，用于算尺寸/启用禁用）")]
    [SerializeField] private Collider2D fusionAreaCollider;

    [Header("相机（不设置则自动 Camera.main）")]
    [SerializeField] private Camera mainCamera;

    [Header("Toggle按钮屏幕偏移（像素）")]
    [SerializeField] private Vector2 toggleScreenOffset = new Vector2(30f, 0f);

    [Header("展开参数（世界单位）")]
    [SerializeField] private float expandDistance = 3.0f;

    [Header("展开方向（世界方向）")]
    [Tooltip("右侧区域： (1,0) 向右；下侧区域：(0,-1) 向下")]
    [SerializeField] private Vector2 expandDirection = new Vector2(1f, 0f);

    [Header("展开时：面板近侧边与标签的间隔（世界单位）")]
    [Tooltip("右侧：用 gapFromNormalX；下侧：用 gapFromNormalY。由 RackManager 传入。")]
    [SerializeField] private float openGapFromTab = 0.0f;

    [Header("DOTween")]
    [SerializeField] private float duration = 0.3f;
    [SerializeField] private Ease ease = Ease.OutCubic;

    private RectTransform toggleButtonRect;
    private TMP_Text toggleLabel;
    private Tween moveTween;
    private IFusionZoneCollapseHandler collapseHandler;

    // 标签锚点：贴在普通区边缘（永远用于 Toggle 定位）
    private Vector3 tabAnchorWorldPos;

    // 沿展开方向的半尺寸（右侧=半宽；下侧=半高）
    private float halfExtentAlongDir = 0.5f;

    //private Vector3 collapsedPos;
    private bool isExpanded;
    private Vector2 cachedSize = Vector2.zero;

    private void Awake()
    {
        if (fusionAreaRoot == null) fusionAreaRoot = transform;
        if (fusionAreaCollider == null && fusionAreaRoot != null)
            fusionAreaCollider = fusionAreaRoot.GetComponentInChildren<Collider2D>();

        if (fusionAreaCollider != null)
        {
            var s = fusionAreaCollider.bounds.size;
            cachedSize = new Vector2(s.x, s.y);
        }

        if (mainCamera == null) mainCamera = Camera.main;

        // 自动创建 Toggle 按钮并绑定
        if (FusionUIRoot.Instance != null)
        {
            toggleButtonRect = FusionUIRoot.Instance.CreateToggleButton(this);
            if (toggleButtonRect != null)
                toggleLabel = toggleButtonRect.GetComponentInChildren<TMP_Text>(true);
        }
        else
        {
            Debug.LogError("[FusionAreaExpanderItem] 场景中不存在 FusionUIRoot（Canvas/UI_Root）", this);
        }

        // 自动寻找桥接组件（不依赖 Gameplay 类型）
        var monos = GetComponentsInParent<MonoBehaviour>(true);
        for (int i = 0; i < monos.Length; i++)
        {
            if (monos[i] is IFusionZoneCollapseHandler h)
            {
                collapseHandler = h;
                break;
            }
        }

        SetExpanded(false, immediate: true);
    }

    private void LateUpdate()
    {
        UpdateToggleButtonPos();
    }

    // =========================
    //  RackManager → Item API
    // =========================

    /// <summary>
    /// 设置“标签(Tab)锚点”（普通区边缘）
    /// Toggle 永远贴这个点（再加屏幕像素偏移）
    /// </summary>
    public void SetTabAnchorWorldPos(Vector3 pos)
    {
        tabAnchorWorldPos = pos;

        // 收起时，面板立即跟到新收起位置（避免普通区移动后面板漂移）
        if (!isExpanded && fusionAreaRoot != null)
            fusionAreaRoot.position = GetClosedCenter();
    }

    /// <summary>设置展开方向</summary>
    public void SetExpandDirection(Vector2 dir)
    {
        if (dir.sqrMagnitude < 0.0001f) dir = Vector2.right;
        expandDirection = dir.normalized;
        RecalcHalfExtentAlongDir();

        if (!isExpanded && fusionAreaRoot != null)
            fusionAreaRoot.position = GetClosedCenter();
    }

    /// <summary>
    /// 设置“展开时标签到面板近侧边的间隔”
    /// - 右侧：gapFromNormalX
    /// - 下侧：gapFromNormalY
    /// </summary>
    public void SetOpenGapFromTab(float gap)
    {
        openGapFromTab = Mathf.Max(0f, gap);

        if (!isExpanded && fusionAreaRoot != null)
            fusionAreaRoot.position = GetClosedCenter();
    }

    /// <summary>给 RackManager 读取：该合成区世界尺寸</summary>
    public Vector2 GetFusionWorldSize()
    {
        if (cachedSize.x > 0.01f && cachedSize.y > 0.01f)
            return cachedSize;

        if (fusionAreaCollider == null) return new Vector2(2f, 2f);
        Vector3 s = fusionAreaCollider.bounds.size;
        return new Vector2(s.x, s.y);
    }

    // =========================
    //  Toggle Click
    // =========================

    /// <summary>按钮点击：展开/收起</summary>
    public void Toggle()
    {
        SetExpanded(!isExpanded, immediate: false);
    }

    private void SetExpanded(bool expanded, bool immediate)
    {
        isExpanded = expanded;

        // 只改文字，不旋转按钮
        if (toggleLabel != null)
            toggleLabel.text = isExpanded ? "×" : "+";

        // 收起前：让 Gameplay 做收尾（驱逐卡牌/或阻止收起）
        if (!expanded && collapseHandler != null)
        {
            bool ok = collapseHandler.OnBeforeCollapse();
            if (!ok)
            {
                // 不允许收起：直接返回（保持展开）
                // 也别忘了 UI 文本回去
                isExpanded = true;
                if (toggleLabel != null) toggleLabel.text = "×";
                return;
            }
        }

        // 合成区收起时禁用 collider（避免误判进入合成区）
        if (fusionAreaCollider != null)
            fusionAreaCollider.enabled = isExpanded;

        RecalcHalfExtentAlongDir();

        Vector3 target = isExpanded ? GetOpenCenter() : GetClosedCenter();

        moveTween?.Kill();

        if (immediate)
        {
            fusionAreaRoot.position = target;
        }
        else
        {
            moveTween = fusionAreaRoot.DOMove(target, duration).SetEase(ease);
        }

        // 展开时显示 FusionAreaFollower 生成的“合成按钮”，收起时隐藏
        var followers = fusionAreaRoot.GetComponentsInChildren<FusionAreaFollower>(true);
        foreach (var f in followers)
            f.SetExpandedVisible(isExpanded);  // 只控制显示/隐藏
    }

    // =========================
    //  Internals
    // =========================

    private void RecalcHalfExtentAlongDir()
    {
        Vector2 size = GetFusionWorldSize();
        float halfW = Mathf.Max(0.01f, size.x * 0.5f);
        float halfH = Mathf.Max(0.01f, size.y * 0.5f);

        // 方向只有(1,0)/(0,-1)，用主轴判断最稳
        if (Mathf.Abs(expandDirection.x) >= Mathf.Abs(expandDirection.y))
            halfExtentAlongDir = halfW;
        else
            halfExtentAlongDir = halfH;
    }

    /// <summary>
    /// 收起中心：标签位于面板“远侧边”
    /// right: tab = panelRightEdge => center = tab - dir*half
    /// down : tab = panelBottom    => center = tab - dir*half （dir为(0,-1)，等价于 +Y half）
    /// </summary>
    private Vector3 GetClosedCenter()
    {
        Vector3 dir3 = new Vector3(expandDirection.x, expandDirection.y, 0f);
        return tabAnchorWorldPos - dir3 * halfExtentAlongDir;
    }

    /// <summary>
    /// 展开中心：标签位于面板“近侧边”，且近侧边与标签间隔 openGapFromTab
    /// right: panelLeftEdge = tab + dir*openGap => center = tab + dir*(openGap + half)
    /// down : panelTopEdge  = tab + dir*openGap => center = tab + dir*(openGap + half)
    /// </summary>
    private Vector3 GetOpenCenter()
    {
        Vector3 dir3 = new Vector3(expandDirection.x, expandDirection.y, 0f);
        return tabAnchorWorldPos + dir3 * (openGapFromTab + halfExtentAlongDir);
    }

    private void UpdateToggleButtonPos()
    {
        if (toggleButtonRect == null || mainCamera == null) return;

        // Toggle按钮永远跟随“收敛位置”
        Vector3 screen = mainCamera.WorldToScreenPoint(tabAnchorWorldPos);
        screen.x += toggleScreenOffset.x;
        screen.y += toggleScreenOffset.y;

        toggleButtonRect.position = screen;
    }

    private void OnDestroy()
    {
        if (toggleButtonRect != null)
            Destroy(toggleButtonRect.gameObject);
    }
}
