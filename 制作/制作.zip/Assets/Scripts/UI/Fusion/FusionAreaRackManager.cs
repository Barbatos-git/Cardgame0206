﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 管理多个 FusionArea 的“收敛位置”布局：
/// 动态容量：根据普通区边长 & 合成区边长计算能放几个
/// - 右侧：沿普通区高度从上往下排（不超过右侧长度/高度）
/// - 下侧：沿普通区宽度从左往右排（不超过下侧长度/宽度）
/// - 总上限 = rightCapacity + bottomCapacity
/// - 自动吸附：普通区 Collider bounds 变化时自动 RebuildLayout
/// </summary>
public class FusionAreaRackManager : MonoBehaviour
{
    [SerializeField] private Collider2D normalAreaCollider;

    [Header("与普通区边界的留白（世界单位）")]
    [SerializeField] private float gapFromNormalX = 0.0f;
    [SerializeField] private float gapFromNormalY = 0.0f;

    [Header("合成区之间的间距（世界单位）")]
    [SerializeField] private float spacing = 0.0f;

    [Header("边角预留")]
    [SerializeField] private float cornerPadding = 0.0f;

    [Header("自动吸附普通区边缘")]
    [SerializeField] private bool autoSnapToNormalEdge = true;

    [Tooltip("bounds 变化超过这个阈值就触发 RebuildLayout（世界单位）")]
    [SerializeField] private float snapEpsilon = 0.001f;

    private readonly List<FusionAreaExpanderItem> items = new();

    // 缓存基准尺寸（避免不同卡导致容量抖动）
    private bool hasBaseSize = false;
    private Vector2 baseSize; // (w,h)

    // 缓存普通区 bounds，用于检测变化
    private Bounds lastNormalBounds;
    private bool hasLastBounds = false;

    private void LateUpdate()
    {
        if (!autoSnapToNormalEdge) return;
        if (normalAreaCollider == null) return;
        if (!hasBaseSize) return; // 没有 item 时不必重排

        Bounds now = normalAreaCollider.bounds;

        if (!hasLastBounds)
        {
            hasLastBounds = true;
            lastNormalBounds = now;
            return;
        }

        if (HasBoundsChanged(lastNormalBounds, now, snapEpsilon))
        {
            lastNormalBounds = now;
            RebuildLayout(); // 自动吸附
        }
    }

    public bool TryRegister(FusionAreaExpanderItem item)
    {
        if (item == null) return false;

        if (!items.Contains(item))
        {
            if (!hasBaseSize)
            {
                baseSize = item.GetFusionWorldSize();
                hasBaseSize = true;

                // 初始化一次 bounds 缓存
                if (normalAreaCollider != null)
                {
                    hasLastBounds = true;
                    lastNormalBounds = normalAreaCollider.bounds;
                }
            }

            int max = GetMaxCount();
            if (items.Count >= max)
            {
                Debug.LogWarning($"[FusionAreaRackManager] FusionArea 已满（max={max}），不再允许生成。", this);
                return false;
            }

            items.Add(item);
            RebuildLayout();
        }

        return true;
    }

    // 兼容旧调用
    public void Register(FusionAreaExpanderItem item) => TryRegister(item);

    public void Unregister(FusionAreaExpanderItem item)
    {
        if (items.Remove(item))
        {
            // 如果清空了，允许下次重新取基准尺寸
            if (items.Count == 0) hasBaseSize = false;
            RebuildLayout();
        }
    }

    public int GetRightCapacity()
    {
        if (!IsReady()) return 0;

        Bounds nb = normalAreaCollider.bounds;
        float normalHeight = Mathf.Max(0f, nb.size.y - cornerPadding);

        float zoneH = baseSize.y;
        if (zoneH <= 0.0001f) return 0;

        // 能放 N 个：N*zoneH + (N-1)*spacing <= normalHeight
        // => N <= (normalHeight + spacing) / (zoneH + spacing)
        int n = Mathf.FloorToInt((normalHeight + spacing) / (zoneH + spacing));
        return Mathf.Max(0, n);
    }

    public int GetBottomCapacity()
    {
        if (!IsReady()) return 0;

        Bounds nb = normalAreaCollider.bounds;
        float normalWidth = Mathf.Max(0f, nb.size.x - cornerPadding);

        float zoneW = baseSize.x;
        if (zoneW <= 0.0001f) return 0;

        int n = Mathf.FloorToInt((normalWidth + spacing) / (zoneW + spacing));
        return Mathf.Max(0, n);
    }

    public int GetMaxCount()
    {
        int r = GetRightCapacity();
        int b = GetBottomCapacity();
        return r + b;
    }

    public bool CanCreateMore() => items.Count < GetMaxCount();

    public void RebuildLayout()
    {
        if (!IsReady()) return;

        Bounds nb = normalAreaCollider.bounds;

        // 同步缓存（避免下一帧又触发）
        hasLastBounds = true;
        lastNormalBounds = nb;

        int rightCap = GetRightCapacity();
        int bottomCap = GetBottomCapacity();

        // 安全：如果容量因为缩放/尺寸变化变小，超出的 item 就不会再摆放（你也可以选择销毁/折叠）
        int max = rightCap + bottomCap;

        float w = baseSize.x;
        float h = baseSize.y;

        for (int i = 0; i < items.Count; i++)
        {
            var it = items[i];
            if (it == null) continue;

            if (i >= max)
            {
                // 超出容量：可以选择不处理 / 或者把它放回某个默认位置
                continue;
            }

            if (i < rightCap)
            {
                // =========================
                // 右侧：Tab 贴右边缘；Panel 在右侧留白后
                // =========================

                // 右侧竖排：从顶部往下
                // 贴边锚点：x = nb.max.x
                float tabX = nb.max.x;
                float tabY = nb.max.y - h * 0.5f - i * (h + spacing);

                Vector3 tabAnchor = new Vector3(tabX, tabY, it.transform.position.z);

                // 右侧区域：向右滑出
                it.SetExpandDirection(new Vector2(1f, 0f));
                it.SetTabAnchorWorldPos(tabAnchor);

                // 从 tab 沿右方向偏移：gapX + 半宽
                float panelOffset = gapFromNormalX + w * 0.5f;
                it.SetOpenGapFromTab(gapFromNormalX);
            }
            else
            {
                // =========================
                // 下侧：Tab 贴下边缘；Panel 在下侧留白后
                // =========================

                // 下侧横排：从左往右
                int bi = i - rightCap;
                if (bi >= bottomCap) continue;

                float tabX = nb.min.x + w * 0.5f + bi * (w + spacing);
                float tabY = nb.min.y;

                Vector3 tabAnchor = new Vector3(tabX, tabY, it.transform.position.z);

                // 下侧区域：向下滑出
                it.SetExpandDirection(new Vector2(0f, -1f));
                it.SetTabAnchorWorldPos(tabAnchor);

                // 从 tab 沿下方向偏移：gapY + 半高
                float panelOffset = gapFromNormalY + h * 0.5f;
                it.SetOpenGapFromTab(gapFromNormalY);
            }
        }
    }

    private bool IsReady()
    {
        if (normalAreaCollider == null) return false;
        if (!hasBaseSize)
        {
            // 如果还没注册任何 zone，也能工作：但容量无法算，返回 false
            return false;
        }
        return true;
    }

    private static bool HasBoundsChanged(Bounds a, Bounds b, float eps)
    {
        // center/size 任一分量变化超过 eps 就算变化
        Vector3 dc = a.center - b.center;
        Vector3 ds = a.size - b.size;
        return (Mathf.Abs(dc.x) > eps || Mathf.Abs(dc.y) > eps || Mathf.Abs(dc.z) > eps ||
                Mathf.Abs(ds.x) > eps || Mathf.Abs(ds.y) > eps || Mathf.Abs(ds.z) > eps);
    }
}
