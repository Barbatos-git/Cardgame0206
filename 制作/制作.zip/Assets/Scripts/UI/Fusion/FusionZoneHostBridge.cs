using UnityEngine;

public sealed class FusionZoneHostBridge : MonoBehaviour, IFusionZoneHost
{
    [SerializeField] private FusionAreaRackManager rackManager;

    private void Awake()
    {
        if (rackManager == null) rackManager = FindObjectOfType<FusionAreaRackManager>();
    }

    public GameObject SpawnFusionZone(GameObject fusionZonePrefab, GameObject ownerCard)
    {
        if (fusionZonePrefab == null)
        {
            Debug.LogError("[FusionZoneHostBridge] fusionZonePrefab is null.");
            return null;
        }
        if (rackManager == null)
        {
            Debug.LogError("[FusionZoneHostBridge] FusionAreaRackManager not found in scene.");
            return null;
        }

        var go = Instantiate(fusionZonePrefab);
        go.name = $"{fusionZonePrefab.name} (Owner={ownerCard?.name})";

        // 关键：“位置/布局”不在这里写死，而是沿用旧系统 RackManager.RebuildLayout
        var item = go.GetComponentInChildren<FusionAreaExpanderItem>(true);
        if (item == null)
        {
            Debug.LogError("[FusionZoneHostBridge] prefab missing FusionAreaExpanderItem.", go);
            Destroy(go);
            return null;
        }

        if (!rackManager.TryRegister(item))
        {
            Debug.LogWarning("[FusionZoneHostBridge] RackManager register failed (maybe full).", this);
            Destroy(go);
            return null;
        }

        return go;
    }

    public void DespawnFusionZone(GameObject spawnedZone)
    {
        if (spawnedZone == null) return;

        if (rackManager != null)
        {
            var item = spawnedZone.GetComponentInChildren<FusionAreaExpanderItem>(true);
            if (item != null) rackManager.Unregister(item);
        }

        Destroy(spawnedZone);
    }
}
