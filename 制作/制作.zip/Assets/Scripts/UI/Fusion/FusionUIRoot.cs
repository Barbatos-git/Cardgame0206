﻿using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Fusion 按钮 UI 的管理器
/// 1) 生成“合成按钮”（给 FusionAreaFollower 用）
/// 2) 生成“Toggle(+/×)按钮”（给 FusionAreaExpanderItem 用）
/// </summary>
public class FusionUIRoot : MonoBehaviour
{
    // 单例（方便 FusionAreaFollower 请求 UI 按钮）
    public static FusionUIRoot Instance { get; private set; }

    [Header("Fusion 按钮的 UI Prefab（RectTransform）")]
    [SerializeField] private RectTransform fusionButtonPrefab;

    [Header("Toggle按钮Prefab（+ / ×，RectTransform）")]
    [SerializeField] private RectTransform toggleButtonPrefab;

    private void Awake()
    {
        // 单例初始化
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("[FusionUIRoot] 已存在实例，将销毁重复对象。");
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    /// <summary>
    /// 生成一个 Fusion 按钮，并绑定到对应 FusionAreaFollower 上
    /// </summary>
    [System.Obsolete]
    public RectTransform CreateFusionButton(FusionAreaFollower owner)
    {
        if (fusionButtonPrefab == null)
        {
            Debug.LogError("[FusionUIRoot] fusionButtonPrefab 未设置！");
            return null;
        }

        // 在 Canvas 下生成一个按钮实例
        RectTransform rect = Instantiate(fusionButtonPrefab, transform);
        FixFloatingButtonRect(rect);

        // 为按钮添加点击事件，绑定到该区域的 Fusion 按钮点击回调
        Button btn = rect.GetComponent<Button>();
        if (btn != null)
        {
            btn.onClick.AddListener(owner.OnFusionButtonClicked);
        }

        return rect;
    }

    /// <summary>
    /// 生成一个“Toggle(+/×)按钮”，并绑定到对应 FusionAreaExpanderItem 上
    /// </summary>
    public RectTransform CreateToggleButton(FusionAreaExpanderItem owner)
    {
        if (toggleButtonPrefab == null)
        {
            Debug.LogError("[FusionUIRoot] toggleButtonPrefab 未设置！");
            return null;
        }

        RectTransform rect = Instantiate(toggleButtonPrefab, transform);
        FixFloatingButtonRect(rect);

        Button btn = rect.GetComponent<Button>();
        if (btn != null)
            btn.onClick.AddListener(owner.Toggle);

        return rect;
    }

    private void FixFloatingButtonRect(RectTransform rect, float w = 48f, float h = 64f)
    {
        rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, w);
        rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, h);

        // 除了真正的 Button 组件所在节点，其他 Graphic 一律不挡射线
        var graphics = rect.GetComponentsInChildren<Graphic>(true);
        foreach (var g in graphics)
            if (g.GetComponent<Button>() == null)
                g.raycastTarget = false;
    }
}
