﻿using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 让 UI Fusion 按钮自动跟随 Fusion 区（矩形 Collider）
///
/// 功能：
/// 1. 自动获取 Fusion 区的 Collider2D（支持挂在子物体上）
/// 2. 自动向 FusionUIRoot 请求生成属于自己的按钮
/// 3. 按钮会自动跟随 Fusion 区底部移动
/// 4. 当 Fusion 区被销毁时，按钮也自动销毁
/// 
/// 状态机：
/// - Hidden   : 按钮不显示（由 Toggle(+/×) 控制展开/收起）
/// - Disabled : 按钮显示但不可点（材料不足/不可合成）
/// - Enabled  : 按钮显示且可点（可合成）
/// 
/// 规则：
/// - Toggle(+/×) 只调用 SetExpandedVisible(bool) 来控制 Hidden/显示
/// - FusionZone / 合成逻辑只调用 SetCanFuse(bool) 来控制 Enabled/Disabled
/// </summary>
public class FusionAreaFollower : MonoBehaviour, IFusionButtonStateSink
{
    [Header("Fusion 区的 Collider（可选）")]
    [Tooltip("如果留空，则会自动在自己或子物体中查找第一个 Collider2D")]
    [SerializeField] private Collider2D fusionAreaCollider;

    [Header("主相机（不设置则自动使用 Camera.main）")]
    [SerializeField] private Camera mainCamera;

    [Header("按钮屏幕坐标偏移量（像素）")]
    [SerializeField] private float offsetY = 0f;   // Y 方向偏移（往下为负）
    [SerializeField] private float offsetX = 0f;     // X 方向微调

    [Header("调用本区域自己的 FusionZone,Core 接口")]
    private IFusionActionSource actionSource;

    // 交互与灰态控制
    [Header("按钮交互/灰态")]
    [SerializeField] private float disabledAlpha = 0.35f;

    private RectTransform buttonRect;     // 生成的 UI 按钮（自动绑定）

    // 组件缓存：Button / CanvasGroup
    private Button cachedButton;
    private CanvasGroup cachedCanvasGroup;

    // 状态机
    private enum UIState { Hidden, Disabled, Enabled }
    private UIState state = UIState.Hidden;

    // 两个“维度”的输入
    private bool visibleExpanded = false; // 由 Toggle 控制（展开才显示）
    private bool canFuse = false;         // 由合成逻辑控制（是否允许合成）

    private void Awake()
    {
        // 自动获取 Collider2D（支持挂在子物体上）
        // 如果在 Inspector 里手动拖了，就用拖的；
        // 如果没拖，就自动在自己和子物体里找第一个 Collider2D。
        // 自动寻找桥接组件（不依赖 FusionZone 类型）
        var monos = GetComponentsInParent<MonoBehaviour>(true);
        for (int i = 0; i < monos.Length; i++)
        {
            if (monos[i] is IFusionActionSource src)
            {
                actionSource = src;
                break;
            }
        }

        if (fusionAreaCollider == null)
        {
            fusionAreaCollider = GetComponentInChildren<Collider2D>();
        }

        if (fusionAreaCollider == null)
        {
            Debug.LogError("[FusionAreaFollower] 未找到 Collider2D！请确认 Fusion 区或其子物体上有 Collider2D。", this);
        }

        // 若相机未指定，自动使用 Camera.main
        if (mainCamera == null)
        {
            mainCamera = Camera.main;
        }
    }

    private void Start()
    {
        // 在 Start 里再去取 FusionUIRoot.Instance，避免执行顺序问题
        if (FusionUIRoot.Instance != null)
        {
            buttonRect = FusionUIRoot.Instance.CreateFusionButton(this);

            // 创建后立刻缓存组件 & 初始化状态
            CacheButtonComponents();
            // 默认：收起 => Hidden；同时不可合成
            visibleExpanded = false;
            canFuse = false;
            RefreshState(force: true);
        }
        else
        {
            Debug.LogError("[FusionAreaFollower] 场景中不存在 FusionUIRoot，请检查 Canvas 设置！（Canvas 下是否有挂 FusionUIRoot 的对象并且激活）", this);
        }
    }

    private void LateUpdate()
    {
        if (fusionAreaCollider == null || buttonRect == null || mainCamera == null)
            return;

        //UpdateButtonPosition();

        // Hidden 状态下不必更新位置（省性能）
        if (state != UIState.Hidden)
            UpdateButtonPosition();
    }

    // ======================
    //  Public API（外部调用）
    // ======================

    /// <summary>
    /// 由 Toggle(+/×) 调用：展开则显示按钮，收起则隐藏按钮。
    /// 注意：这里只改变“可见性”，不改变是否可合成。
    /// </summary>
    public void SetExpandedVisible(bool expandedVisible)
    {
        visibleExpanded = expandedVisible;
        RefreshState(force: false);
    }

    /// <summary>
    /// 由 FusionZone/规则系统调用：是否允许合成（决定 Enabled/Disabled）
    /// 注意：如果当前是收起状态，按钮仍然 Hidden（不会显示）。
    /// </summary>
    public void SetCanFuse(bool canFuseNow)
    {
        canFuse = canFuseNow;
        RefreshState(force: false);
    }

    /// <summary>
    /// 兼容旧接口：以前 ExpanderItem 调用的是 SetUIButtonActive(isExpanded)
    /// [CHANGED] 现在把它当作“展开可见性”来处理（Hidden/显示）
    /// </summary>
    public void SetUIButtonActive(bool active)
    {
        SetExpandedVisible(active);
    }

    /// <summary>
    /// 当 Fusion 按钮被点击时执行
    /// 这里调用 FusionZone / FusionManager 的合成逻辑
    /// </summary>
    public void OnFusionButtonClicked()
    {
        Debug.Log($"[FusionAreaFollower] Fusion 按钮被点击：{gameObject.name}");

        // 保险：不可合成时不触发
        if (!canFuse)
        {
            Debug.Log("[FusionAreaFollower] 当前不可合成：忽略点击。");
            return;
        }

        actionSource?.RequestFuse();
    }

    // ======================
    //  Internals
    // ======================

    private void CacheButtonComponents()
    {
        if (buttonRect == null) return;

        cachedButton = buttonRect.GetComponentInChildren<Button>(true);
        cachedCanvasGroup = buttonRect.GetComponentInChildren<CanvasGroup>(true);

        // 如果 prefab 没挂 CanvasGroup，就自动加一个（最稳）
        if (cachedCanvasGroup == null)
            cachedCanvasGroup = buttonRect.gameObject.AddComponent<CanvasGroup>();
    }

    /// <summary>
    /// 根据 visibleExpanded + canFuse 计算目标状态，并应用到 UI
    /// </summary>
    private void RefreshState(bool force)
    {
        if (buttonRect == null) return;

        UIState next =
            !visibleExpanded ? UIState.Hidden :
            canFuse ? UIState.Enabled :
            UIState.Disabled;

        if (!force && next == state) return;

        state = next;
        ApplyStateToUI();

        // 进入可见状态时立刻对齐一次位置
        if (state != UIState.Hidden)
            UpdateButtonPosition();
    }

    /// <summary>
    /// 把状态机状态映射到：显示/隐藏 + 可点击 + 灰态
    /// </summary>
    private void ApplyStateToUI()
    {
        if (buttonRect == null) return;

        bool visible = (state != UIState.Hidden);
        buttonRect.gameObject.SetActive(visible);

        if (!visible) return;

        bool interactable = (state == UIState.Enabled);

        if (cachedButton != null)
            cachedButton.interactable = interactable;

        if (cachedCanvasGroup != null)
        {
            cachedCanvasGroup.alpha = interactable ? 1f : disabledAlpha;
            cachedCanvasGroup.blocksRaycasts = interactable; // 不可点时不挡其他UI
        }
    }


    /// <summary>
    /// 更新按钮位置，使其跟随 Fusion 区的 “底边中心”
    /// </summary>
    private void UpdateButtonPosition()
    {
        // 1. 获取碰撞体范围（注意：Collider 在子物体上也没问题）
        Bounds b = fusionAreaCollider.bounds;

        // 2. 底边中心的世界坐标
        Vector3 bottomCenterWorld = new Vector3(
            b.center.x,
            b.min.y,
            0f
        );

        // 3. 世界坐标 → UI 屏幕坐标
        Vector3 screenPos = mainCamera.WorldToScreenPoint(bottomCenterWorld);

        // 4. 根据需要微调偏移
        screenPos.x += offsetX;
        screenPos.y += offsetY;

        // 5. 更新 UI 按钮位置
        buttonRect.position = screenPos;
    }

    private void OnDestroy()
    {
        // 当 Fusion 区销毁时，连带销毁按钮
        if (buttonRect != null)
        {
            Destroy(buttonRect.gameObject);
        }
    }
}
