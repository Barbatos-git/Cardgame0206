﻿using UnityEngine;
using UnityEngine.UI;
using CardGame.Core.Pause;

namespace CardGame.UI.Pause
{
    public class PauseButtonUI : MonoBehaviour
    {
        [Header("UI References")]
        [SerializeField] private Button button;
        [SerializeField] private Image targetImage; // 你按钮上显示图标的Image

        [Header("Sprites")]
        [SerializeField] private Sprite pauseSprite;   // 显示“暂停”图
        [SerializeField] private Sprite resumeSprite;  // 显示“开始/继续”图

        private bool _isPaused;

        private void Reset()
        {
            button = GetComponent<Button>();

            // 如果按钮本体就是图片按钮，这句就能自动抓到
            targetImage = GetComponent<Image>();
        }

        private void OnEnable()
        {
            if (button != null)
                button.onClick.AddListener(OnClick);

            ApplyUI(_isPaused);
        }

        private void OnDisable()
        {
            if (button != null)
                button.onClick.RemoveListener(OnClick);
        }

        private void OnClick()
        {
            _isPaused = !_isPaused;
            ApplyUI(_isPaused);

            // 需要的话再通知你的暂停系统
            PauseEvents.RaisePauseChanged(_isPaused);
        }

        private void ApplyUI(bool paused)
        {
            if (targetImage == null) return;

            targetImage.sprite = paused ? resumeSprite : pauseSprite;
        }
    }
}
