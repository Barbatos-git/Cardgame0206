﻿using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "NewCardDatabase", menuName = "Game Data/Card Database")]
public class JsonCardDatabase : ScriptableObject
{
    public List<CardData> allCards = new List<CardData>();

    // 可添加根据ID查询卡牌的方法
    public CardData GetCardByID(int id)
    {
        return allCards.Find(card => card.id == id);
    }
}