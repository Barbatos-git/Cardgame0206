﻿using System.Collections.Generic;
using UnityEngine;

public class CardOwnershipManager : MonoBehaviour
{
    public static CardOwnershipManager Instance;

    // cardId -> count
    private Dictionary<int, int> ownedCards = new Dictionary<int, int>();

    private void Awake()
    {
        Instance = this;
    }

    public void AddCard(int cardId, int amount = 1)
    {
        if (!ownedCards.ContainsKey(cardId))
            ownedCards[cardId] = 0;

        ownedCards[cardId] += amount;

        // 通知任务系统
        //TaskManager.Instance?.NotifyCardChanged(cardId, ownedCards[cardId]);
    }

    public void RemoveCard(int cardId, int amount = 1)
    {
        if (!ownedCards.ContainsKey(cardId))
            return;

        ownedCards[cardId] -= amount;
        if (ownedCards[cardId] < 0)
            ownedCards[cardId] = 0;

        //TaskManager.Instance?.NotifyCardChanged(cardId, ownedCards[cardId]);
    }

    public int GetCardCount(int cardId)
    {
        return ownedCards.TryGetValue(cardId, out int count) ? count : 0;
    }
}
