﻿using System.Collections.Generic;
using UnityEngine;

public class CraftManager : MonoBehaviour
{
    public CraftData craftDB;
    public JsonCardDatabase cardDB;

    /// <summary>
    /// 根据两张卡牌，判断能否合成
    /// </summary>
    public CardData TryCraft(CardData a, CardData b)
    {
        List<int> input = new List<int> { a.id, b.id };

        // 排序避免顺序影响（例如 木头+石头 和 石头+木头）
        input.Sort();

        foreach (var recipe in craftDB.recipes)
        {
            if (recipe.inputCardIDs.Count != 2)
                continue;

            List<int> r = new List<int>(recipe.inputCardIDs);
            r.Sort();

            // 完全匹配就返回
            if (r[0] == input[0] && r[1] == input[1])
            {
                return cardDB.GetCardByID(recipe.outputCardID);
            }
        }

        return null;
    }
}
