﻿using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class CardData
{
    public int id;
    public string cardName;

    public enum CardType
    {
        NaturalResource,
        BioResource,
        Food,
        Material,
        Equipment,
        Structure
        //追加は以下
    }
    public CardType cardType;
    public string iconPath;//图标路径
    [TextArea]
    public string description;//描述/提示
    public bool isPermanent = false;//是否永久
    public int sellPrice = 0;//售出价格
    public int value = -1;//物品价值
}

[System.Serializable]
public class CardDataWrapper
{
    public List<CardData> allCards;
}