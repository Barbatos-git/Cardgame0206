﻿using System.Collections.Generic;

[System.Serializable]
public class CraftDataWrapper
{
    public List<CraftRecipe> recipes;
}
