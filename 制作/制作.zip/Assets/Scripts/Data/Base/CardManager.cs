﻿using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class CardManager : MonoBehaviour
{
    public static CardManager Instance { get; private set; }

    // 运行时存储所有卡牌数据
    private Dictionary<int, CardData> cardDictionary = new Dictionary<int, CardData>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            LoadCardData(); // 核心：在游戏启动时加载数据
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void LoadCardData()
    {
        // 1. 确定文件路径
        // Application.streamingAssetsPath 指向 StreamingAssets 文件夹
        string filePath = Path.Combine(Application.streamingAssetsPath, "cards.json");

        if (File.Exists(filePath))
        {
            // 2. 读取文件内容
            string jsonText = File.ReadAllText(filePath);

            // 3. 解析 JSON
            // 使用 Unity 内置的 JsonUtility 解析器
            CardDataWrapper wrapper = JsonUtility.FromJson<CardDataWrapper>(jsonText);

            // 4. 将数据存入字典，方便快速查找
            cardDictionary.Clear();
            foreach (var card in wrapper.allCards)
            {
                cardDictionary.Add(card.id, card);
            }

            Debug.Log($"成功从 JSON 加载 {cardDictionary.Count} 张卡牌数据。");
        }
        else
        {
            Debug.LogError($"未找到卡牌数据文件: {filePath}");
        }
    }

    // 提供一个公共方法供其他脚本调用数据
    public CardData GetCardByID(int id)
    {
        if (cardDictionary.TryGetValue(id, out CardData card))
        {
            return card;
        }
        Debug.LogError($"卡牌ID {id} 不存在！");
        return null;
    }
}