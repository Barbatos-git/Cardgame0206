﻿using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class CraftRecipe
{
    public List<int> inputCardIDs;  // 输入卡牌ID们
    public int outputCardID;        // 输出卡牌ID
    public int outputCount = 1;     // 合成得到数量 (可选)
}

[CreateAssetMenu(fileName = "CraftDatabase", menuName = "Game Data/Craft Database")]
public class CraftData : ScriptableObject
{
    public List<CraftRecipe> recipes;
}
