﻿using UnityEngine;

namespace CardGame.Data.Time
{
    [CreateAssetMenu(fileName = "TimeConfig", menuName = "CardGame/Config/TimeConfig")]
    public class TimeConfigSO : ScriptableObject
    {
        [Min(1)] public int ticksPerDay = 20;

        [Header("Auto Mode (可选)")]
        public bool autoTick = false;
        [Min(0.01f)] public float secondsPerTick = 0.5f;
    }
}
