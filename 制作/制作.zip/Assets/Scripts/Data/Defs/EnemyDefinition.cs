using System;
using System.Collections.Generic;
using UnityEngine;

namespace CardGame.Data.Defs
{
    [CreateAssetMenu(menuName = "CardGame/Defs/EnemyDefinition")]
    public class EnemyDefinition : ScriptableObject
    {
        public string enemyId = "enemy_slime";
        public string displayName = "Slime";
        [Header("Combat")]
        public int attack = 1;
        public int hp = 3;
        public float attackCooldown = 1.2f;

        [Header("AI")]
        public float searchRadius = 2.5f;
        public float attackRange = 0.8f;

        [Header("Drops (optional)")]
        public List<DropEntry> drops = new();

        [Serializable]
        public class DropEntry
        {
            [Tooltip("CardId in card.json")]
            public string cardId;

            [Range(0f, 1f)]
            public float chance = 0.25f;

            [Min(1)]
            public int minAmount = 1;

            [Min(1)]
            public int maxAmount = 1;
        }
    }
}
