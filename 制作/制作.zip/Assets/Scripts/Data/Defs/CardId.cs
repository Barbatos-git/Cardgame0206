namespace CardGame.Data.Defs
{
    /// <summary>
    /// 識別子（後でAddressables/CSV化も容易）
    /// </summary>
    public static class CardId
    {
        public const string Character_Default = "character_default";
        public const string Weapon_Sword = "weapon_sword";
        public const string Enemy_Slime = "enemy_slime";
    }
}
