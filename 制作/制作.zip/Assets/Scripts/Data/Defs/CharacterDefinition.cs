using UnityEngine;

namespace CardGame.Data.Defs
{
    [CreateAssetMenu(menuName = "CardGame/Defs/CharacterDefinition")]
    public class CharacterDefinition : ScriptableObject
    {
        public string characterId = "character_default";
        public string displayName = "Villager";
        public int baseAttack = 1;
        public int baseHP = 5;

        [Header("Visual (optional)")]
        [Tooltip("未装备武器时使用的立绘（为空则使用 CardDefinition.artwork）")]
        public Sprite normalArtworkOverride;

        [Tooltip("装备武器时使用的立绘（为空则不切换）")]
        public Sprite armedArtworkOverride;

        /// <summary> 探索で素材を生む間隔（秒） </summary>
        public float exploreInterval = 6f;

        /// <summary> 采集で素材を生む間隔（秒） </summary>
        public float gatherInterval = 5f;
    }
}
