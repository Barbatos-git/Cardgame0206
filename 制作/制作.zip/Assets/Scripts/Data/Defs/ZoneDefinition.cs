using UnityEngine;

namespace CardGame.Data.Defs
{
    public enum ZoneKind
    {
        Exploration,
        Gathering_Wood,
        Gathering_Stone,
        Combat
    }

    [CreateAssetMenu(menuName = "CardGame/Defs/ZoneDefinition")]
    public class ZoneDefinition : ScriptableObject
    {
        public string zoneId = "zone_explore";
        public string displayName = "Exploration";
        public ZoneKind kind = ZoneKind.Exploration;
    }
}
