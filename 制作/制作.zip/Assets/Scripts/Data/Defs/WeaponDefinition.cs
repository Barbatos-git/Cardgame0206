using UnityEngine;

namespace CardGame.Data.Defs
{
    [CreateAssetMenu(menuName = "CardGame/Defs/WeaponDefinition")]
    public class WeaponDefinition : ScriptableObject
    {
        public string weaponId = "weapon_sword";
        public string displayName = "Sword";
        public int attackBonus = 2;
        public int hpBonus = 0;
        public bool isRanged = false;
    }
}
