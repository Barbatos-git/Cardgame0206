﻿using UnityEngine;

/// <summary>
/// 标签驱动的合成规则：
/// - requiredAll: 组合后的标签中必须全部包含
/// - requiredAny: 至少包含其中一个（可选）
/// - forbidden: 不能包含的标签（可选）
/// </summary>
[CreateAssetMenu(fileName = "FusionRule", menuName = "Card Game/Fusion Rule")]
public class FusionRule : ScriptableObject
{
    [Header("匹配条件")]
    public CardTag requiredAll;   // 必须全部具备的标签
    public CardTag requiredAny;   // 至少具备其中一个（可为 None）
    public CardTag forbidden;     // 不能包含的标签

    [Header("结果")]
    public CardDefinition result; // 合成产物

    [Header("优先级（数值越大优先）")]
    public int priority = 0;
}
