﻿using UnityEngine;

/// <summary>
/// 堆叠规则：描述某种卡牌是否可以堆叠、最多堆多少张
/// </summary>
[CreateAssetMenu(fileName = "StackRule", menuName = "Card Game/Stack Rule")]
public class StackRule : ScriptableObject
{
    [Header("堆叠目标卡牌类型")]
    public CardDefinition card;      // 哪种卡适用这个规则（比如“木材”）

    [Header("堆叠设置")]
    public bool stackable = true;    // 是否允许堆叠
    public int maxStackSize = 99;    // 单堆最多几张（比如木材最多 x99）
}
