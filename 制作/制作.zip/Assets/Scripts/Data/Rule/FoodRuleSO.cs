﻿using UnityEngine;

namespace CardGame.Data.Food
{
    [CreateAssetMenu(fileName = "FoodRule", menuName = "CardGame/Config/FoodRule")]
    public class FoodRuleSO : ScriptableObject
    {
        [Header("每天每个单位消耗的食物量（整数版）")]
        [Min(0)] public int foodPerUnitPerDay = 1;

        [Header("不够食物时：每缺 1 份要扣多少HP（先留接口）")]
        [Min(0)] public int hpLossPerMissingFood = 1;
    }
}
