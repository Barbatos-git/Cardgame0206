﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class StackRulesManager : MonoBehaviour
{
    public static StackRulesManager Instance { get; private set; }

    [Serializable]
    public class StackRuleEntry
    {
        [Header("识别用（随便写）")]
        public string name = "New Rule";

        [Header("优先级（越大越优先匹配）")]
        public int priority = 0;

        [Header("可选：指定某一张卡（用于特殊覆盖规则）")]
        public CardDefinition specificCard;

        [Header("可选：按标签匹配（specificCard 不为空时可忽略）")]
        public CardTag requiredAll = CardTag.None; // 必须全包含
        public CardTag requiredAny = CardTag.None; // 至少包含一个（None 表示不要求）
        public CardTag forbidden = CardTag.None;    // 不能包含

        [Header("堆叠设置")]
        public bool stackable = true;
        public int maxStackSize = 99;
    }

    [Header("堆叠规则列表（按优先级从高到低匹配）")]
    public List<StackRuleEntry> rules = new List<StackRuleEntry>();

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else { Destroy(gameObject); return; }

        // 确保 priority 高的先匹配
        rules.Sort((a, b) => b.priority.CompareTo(a.priority));
    }

    /// <summary>
    /// 查询某个卡牌的堆叠规则（如果没有配置，则视为不能堆叠）
    /// </summary>
    public bool TryGetRule(CardDefinition def, out StackRuleEntry rule)
    {
        rule = null;
        if (def == null) return false;

        for (int i = 0; i < rules.Count; i++)
        {
            var r = rules[i];
            if (r == null) continue;
            if (IsMatch(def, r))
            {
                rule = r;
                return true;
            }
        }

        return false; // 没配置到就视为不可堆叠
    }

    /// <summary>
    /// 这两张卡在“规则层面”能否堆叠（这里只考虑同一 CardDefinition）
    /// </summary>
    public bool CanStack(CardDefinition a, CardDefinition b, out StackRuleEntry rule)
    {
        rule = null;
        if (a == null || b == null) return false;
        if (a != b) return false; // 仍沿用你原先逻辑：同类卡才能堆叠

        if (!TryGetRule(a, out rule)) return false;
        return rule.stackable;
    }

    private bool IsMatch(CardDefinition def, StackRuleEntry rule)
    {
        // 1) 指定卡：最高精度
        if (rule.specificCard != null)
            return rule.specificCard == def;

        // 2) Tag 匹配
        var tags = def.tags;

        if ((tags & rule.forbidden) != CardTag.None)
            return false;

        if ((tags & rule.requiredAll) != rule.requiredAll)
            return false;

        if (rule.requiredAny != CardTag.None &&
            (tags & rule.requiredAny) == CardTag.None)
            return false;

        return true;
    }
}
