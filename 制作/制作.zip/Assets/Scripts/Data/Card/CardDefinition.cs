﻿using CardGame.Data.Defs;
using UnityEngine;

[CreateAssetMenu(fileName = "CardDefinition", menuName = "Card Game/Card Definition")]
public class CardDefinition : ScriptableObject
{
    [Header("基础信息")]
    public string id;          // 唯一ID，例如 "wood", "stone"
    public string displayName; // 显示名称
    public Sprite artwork;     // 卡牌图片

    [TextArea]
    public string description; // 描述文本

    [Header("简单属性（以后可以扩展）")]
    public int level;

    [Header("标签（支持多选）")]
    public CardTag tags;

    public enum CardRarity
    {
        Common,
        Uncommon,
        Rare,
        Epic,
        Legendary
    }

    [Header("稀有度（资源耐久用）")]
    public CardRarity rarity = CardRarity.Common;

    // ===== 新增：兼容人物/敌人/武器系统（可选引用，不影响旧卡） =====
    [Header("扩展数据（新系统，可不填）")]
    public CharacterDefinition characterDef; // tags 包含 Character 时使用
    public EnemyDefinition enemyDef;         // tags 包含 Enemy 时使用
    public WeaponDefinition weaponDef;       // tags 包含 Weapon 时使用
}
