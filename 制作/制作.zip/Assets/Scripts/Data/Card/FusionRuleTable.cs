using System;
using System.Collections.Generic;

[Serializable]
public class FusionRuleTable
{
    public List<TagRule> tagRules = new();
    public List<IdRule> idRules = new();

    [Serializable]
    public class TagRule
    {
        public List<string> requiredAll;
        public List<string> requiredAny;
        public List<string> forbidden;
        public string outputId;
        public float seconds = 1.5f;
        public int priority = 0;
    }

    [Serializable]
    public class IdRule
    {
        public List<string> inputs;
        public string outputId;
        public float seconds = 1.0f;
    }
}
