﻿using System;

/// <summary>
/// 卡牌的属性标签（可多选，使用位掩码）
/// </summary>
[Flags]
public enum CardTag
{
    None = 0,
    Material = 1 << 0,
    Wood = 1 << 1,
    Stone = 1 << 2,
    Food = 1 << 3,

    // ===== 新系统：类型/战斗扩展（新增）=====
    Character = 1 << 4,   // 人物卡
    Enemy = 1 << 5,   // 敌人卡
    Weapon = 1 << 6,  // 武器卡

    // 可选：战斗/行为标签（后续用得上）
    CanFight = 1 << 7,
    CanGather = 1 << 8,

    // 以后想扩展什么：Water / Magic / Animal 等，直接加
    Resource = 1 << 9,
    Natural = 1 << 10,
    IronOre = 1 << 11,
    Ore = 1 << 12,
    GoldOre = 1 << 13,
    Bio = 1 << 14,
    Processed = 1 << 15,
    Equipment = 1 << 16,
    Resin = 1 << 17,
    Alloy = 1 << 18,
    Quartz = 1 << 19,
    Carapace = 1 << 20,
    Pheromone = 1 << 21,
    Gland = 1 << 22,
    Rebar = 1 << 23,
    Clay = 1 << 24,
    BioOre = 1 << 25,
    Crystal = 1 << 26,
    FusionZoneSource = 1 << 27,

    //===== 村民标记 =====
    Villager = 1 << 28,
}
