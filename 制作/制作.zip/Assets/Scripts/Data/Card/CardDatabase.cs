﻿using System.Collections.Generic;
using UnityEngine;

public class CardDatabase : MonoBehaviour
{
    public static CardDatabase Instance { get; private set; }

    [Header("卡牌定义列表")]
    public List<CardDefinition> allCards;

    [Header("合成规则列表")]
    public List<FusionRule> fusionRules;

    private Dictionary<string, CardDefinition> idToCard = new Dictionary<string, CardDefinition>();

    // 关键：在任何 Scene Awake 之前创建
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Bootstrap()
    {
        if (Instance != null) return;

        // 如果场景里已经放了一个（比如你 GameManager 上挂着），这里先找一下
        var existing = Object.FindObjectOfType<CardDatabase>();
        if (existing != null)
        {
            Instance = existing;
            Instance.BuildIndex();
            Object.DontDestroyOnLoad(existing.gameObject);
            return;
        }
    }

    private void Awake()
    {
        // 兼容：场景里手动挂了 CardDatabase 的情况
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        // 建立 id -> CardDefinition 的索引
        idToCard.Clear();
        foreach (var card in allCards)
        {
            if (card != null && !string.IsNullOrEmpty(card.id))
            {
                idToCard[card.id] = card;
            }
        }
    }

    // 把索引逻辑抽出来，Bootstrap/Awake 都能调用
    public void BuildIndex()
    {
        idToCard.Clear();

        if (allCards == null) return;

        foreach (var card in allCards)
        {
            if (card != null && !string.IsNullOrEmpty(card.id))
                idToCard[card.id] = card;
        }
    }

    public CardDefinition GetCardById(string id)
    {
        idToCard.TryGetValue(id, out var def);
        return def;
    }

    /// <summary>
    /// 标签驱动：根据两张卡的 tags 组合，匹配 FusionRule。
    /// </summary>
    public CardDefinition GetFusionResult(CardDefinition a, CardDefinition b)
    {
        if (a == null || b == null) return null;

        CardTag combined = a.tags | b.tags;

        FusionRule bestRule = null;

        foreach (var rule in fusionRules)
        {
            if (rule == null || rule.result == null) continue;

            if (!IsRuleMatched(rule, combined)) continue;

            // 选优先级最高的规则（避免多个规则冲突）
            if (bestRule == null || rule.priority > bestRule.priority)
            {
                bestRule = rule;
            }
        }

        return bestRule != null ? bestRule.result : null;
    }

    /// <summary>
    /// 传入「已经合并好的标签集合」，根据 FusionRule 找结果。
    /// 用于涌现式：一次性把合成区所有素材的标签 OR 起来后决定要产出什么。
    /// </summary>
    public CardDefinition GetFusionResultByTags(CardTag combined)
    {
        FusionRule bestRule = null;

        foreach (var rule in fusionRules)
        {
            if (rule == null || rule.result == null) continue;

            if (!IsRuleMatched(rule, combined)) continue;

            // 选优先级最高的规则（避免多个规则冲突）
            if (bestRule == null || rule.priority > bestRule.priority)
            {
                bestRule = rule;
            }
        }

        return bestRule != null ? bestRule.result : null;
    }


    private bool IsRuleMatched(FusionRule rule, CardTag combined)
    {
        // 必须包含 requiredAll 的全部标签
        if ((combined & rule.requiredAll) != rule.requiredAll)
            return false;

        // 至少包含 requiredAny 中的一个（若不为 None）
        if (rule.requiredAny != CardTag.None &&
            (combined & rule.requiredAny) == CardTag.None)
            return false;

        // 不能包含 forbidden 中的任何标签
        if (rule.forbidden != CardTag.None &&
            (combined & rule.forbidden) != CardTag.None)
            return false;

        return true;
    }
}
